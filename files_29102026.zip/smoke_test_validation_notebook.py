# Databricks notebook source
# MAGIC %md
# MAGIC # Lakehouse Smoke Test – Validation Notebook
# MAGIC Companion to **Smoke_Test_Tracker.xlsx**. Each cell header shows the tracker TC IDs it provides evidence for.
# MAGIC Run on a policy-compliant cluster in **Standard (shared)** access mode as the tester, then as the job service principal where noted.
# MAGIC Fill the widgets first. Nothing in this notebook writes data except the explicitly marked idempotency checks.

# COMMAND ----------

dbutils.widgets.text("prefix", "gcp_dwhbi_all", "Catalog prefix")
dbutils.widgets.dropdown("env", "dev", ["dev", "uat", "prod"], "Environment")
dbutils.widgets.text("bronze_table", "kcl.adt_taskstatus", "Bronze schema.table")
dbutils.widgets.text("kafka_table", "tia.nonlife_policy_overview_sync_event", "Kafka bronze schema.table")
dbutils.widgets.text("silver_table", "ods_s_sales.fact_task", "Silver schema.table")
dbutils.widgets.text("silver_bk", "task_id", "Silver business key column")
dbutils.widgets.text("gold_table", "dm_sales_cockpit.fact_sales_funnel", "Gold schema.table")
dbutils.widgets.text("secret_scope", "kv-ods-dbx", "Secret scope")

P   = dbutils.widgets.get("prefix")
ENV = dbutils.widgets.get("env")
CAT = {l: f"{P}_{l}_{ENV}" for l in ["bronze", "silver", "gold", "meta"]}
BRZ = f"{CAT['bronze']}.{dbutils.widgets.get('bronze_table')}"
KAF = f"{CAT['bronze']}.{dbutils.widgets.get('kafka_table')}"
SLV = f"{CAT['silver']}.{dbutils.widgets.get('silver_table')}"
BK  = dbutils.widgets.get("silver_bk")
GLD = f"{CAT['gold']}.{dbutils.widgets.get('gold_table')}"
results = []
def check(tc, desc, ok, detail=""):
    results.append((tc, desc, "PASS" if ok else "FAIL", str(detail)[:500]))
    print(f"[{'PASS' if ok else 'FAIL'}] {tc} {desc} {detail}")
print(CAT, BRZ, KAF, SLV, GLD, sep="\n")

# COMMAND ----------

# MAGIC %md ## 1. Network – NET-004, NET-007..009, NET-012..014

# COMMAND ----------

import subprocess, socket
def tcp(host, port, timeout=5):
    try:
        socket.create_connection((host, port), timeout=timeout).close(); return True
    except Exception as e:
        return False
def resolve(host):
    try: return socket.gethostbyname(host)
    except Exception as e: return f"ERR {e}"

for acct in ["land", "bronze", "silver", "gold"]:
    h = f"stods{acct}gcp{ENV}weu.dfs.core.windows.net"
    ip = resolve(h)
    check("NET-004", f"DNS {h}", ip.startswith(("10.", "172.", "192.168.")), ip)

kafka = {"dev": "bt", "uat": "bt", "prod": "bp"}[ENV]
for n in [1, 2, 3]:
    check("NET-007", f"Kafka czsmsgkaf{kafka}{n}:9093", tcp(f"czsmsgkaf{kafka}{n}.cpas.cz", 9093))
    check("NET-008", f"Schema Registry czsmsgkaf{kafka}{n}:18082", tcp(f"czsmsgkaf{kafka}{n}.cpas.cz", 18082))

ora = {"dev": [("suntest04.cpoj.cz", 1530)], "uat": [("sunrac04.cpoj.cz", 1530), ("suntest04.cpoj.cz", 1530)], "prod": [("sunrac03.cpoj.cz", 1521)]}[ENV]
for h, p in ora:
    check("NET-009", f"Oracle {h}:{p}", tcp(h, p))

if ENV != "prod":  # negative tests: prod must NOT be reachable from non-prod
    check("NET-013", "PROD Kafka NOT reachable", not tcp("czsmsgkafbp1.cpas.cz", 9093))
    check("NET-014", "PROD Oracle NOT reachable", not tcp("sunrac03.cpoj.cz", 1521))
check("NET-012", "Internet egress blocked (google.com:443)", not tcp("www.google.com", 443), "PASS = blocked")

# COMMAND ----------

# MAGIC %md ## 2. Secrets – KV-003, KV-005

# COMMAND ----------

scope = dbutils.widgets.get("secret_scope")
scopes = {s.name: s for s in dbutils.secrets.listScopes()}
check("KV-003", f"Secret scope {scope} exists", scope in scopes)
if scope in scopes:
    keys = [k.key for k in dbutils.secrets.list(scope)]
    print("Secret names:", keys)
    if keys:
        print("Redaction check (must print [REDACTED]):", dbutils.secrets.get(scope, keys[0]))

# COMMAND ----------

# MAGIC %md ## 3. Workspace & metastore – DBW-002, DBW-005

# COMMAND ----------

print("Metastore:", spark.sql("SELECT current_metastore()").first()[0])
try:
    n = spark.sql("SHOW TABLES IN hive_metastore.default").count()
    check("DBW-005", "hive_metastore unused", n == 0, f"{n} tables")
except Exception as e:
    check("DBW-005", "hive_metastore access disabled", True, str(e)[:120])

# COMMAND ----------

# MAGIC %md ## 4. Unity Catalog – UC-001, UC-002, UC-007..011, UC-016, UC-019..021

# COMMAND ----------

cats = [r.catalog for r in spark.sql(f"SHOW CATALOGS LIKE '{P}_*'").collect()]
for l, c in CAT.items():
    check("UC-001", f"Catalog {c} exists", c in cats)
    if c in cats:
        d = {r[0]: r[1] for r in spark.sql(f"DESCRIBE CATALOG EXTENDED {c}").collect()}
        root = d.get("Storage Root", "") or d.get("Storage Location", "")
        exp = {"bronze": "stodsbronze", "silver": "stodssilver", "gold": "stodsgold"}.get(l)
        check("UC-002", f"{c} managed location on {exp}", (exp is None) or (exp in root), root)

for l in ["bronze", "silver", "gold"]:
    for s in spark.sql(f"SHOW SCHEMAS IN {CAT[l]}").collect():
        name = s[0]
        if name == "information_schema": continue
        import re
        check("UC-007/008/009", f"{CAT[l]}.{name} lower_snake & <=22 chars",
              bool(re.fullmatch(r"[a-z][a-z0-9_]*", name)) and len(name) <= 22, len(name))

# COMMAND ----------

# UC-010: no external tables in project catalogs (managed tables only)
ext = spark.sql(f"""
  SELECT table_catalog, table_schema, table_name, table_type
  FROM system.information_schema.tables
  WHERE table_catalog LIKE '{P}%' AND table_catalog LIKE '%_{ENV}'
    AND table_type NOT IN ('MANAGED','VIEW','MATERIALIZED_VIEW','STREAMING_TABLE','METRIC_VIEW')
""")
display(ext); check("UC-010", "No EXTERNAL tables", ext.count() == 0, ext.count())

# UC-011: type + location of sample tables
for t in [BRZ, KAF, SLV, GLD]:
    try:
        d = {r[0]: r[1] for r in spark.sql(f"DESCRIBE TABLE EXTENDED {t}").collect()}
        check("UC-011", f"{t} is MANAGED", d.get("Type") == "MANAGED", d.get("Location"))
        check("UC-013", f"{t} is Delta", (d.get("Provider") or "").lower() == "delta", d.get("Provider"))
    except Exception as e:
        check("UC-011", f"{t} exists", False, e)

# COMMAND ----------

# UC-016 / IAM-017: grants per schema, no direct user grants
display(spark.sql(f"""
  SELECT catalog_name, schema_name, grantee, privilege_type
  FROM system.information_schema.schema_privileges
  WHERE catalog_name LIKE '{P}%_{ENV}' ORDER BY 1,2,3"""))
users = spark.sql(f"""
  SELECT grantee, table_catalog, table_schema, table_name, privilege_type FROM system.information_schema.table_privileges
  WHERE table_catalog LIKE '{P}%_{ENV}' AND grantee LIKE '%@%'
  UNION ALL
  SELECT grantee, catalog_name, schema_name, NULL, privilege_type FROM system.information_schema.schema_privileges
  WHERE catalog_name LIKE '{P}%_{ENV}' AND grantee LIKE '%@%'""")
check("IAM-017", "No direct grants to individual users", users.count() == 0, users.count())

# COMMAND ----------

# UC-019 / UC-020 / UC-021: tags and comments
req = ["environment", "cost_center", "data_domain", "data_classification", "layer", "owner"]
st = spark.sql(f"SELECT catalog_name, schema_name, tag_name FROM system.information_schema.schema_tags WHERE catalog_name LIKE '{P}%_{ENV}'").toPandas()
schemas = spark.sql(f"SELECT catalog_name, schema_name FROM system.information_schema.schemata WHERE catalog_name LIKE '{P}%_{ENV}' AND schema_name <> 'information_schema'").toPandas()
for _, s in schemas.iterrows():
    have = set(st[(st.catalog_name == s.catalog_name) & (st.schema_name == s.schema_name)].tag_name)
    miss = [t for t in req if t not in have]
    check("UC-019", f"Tags on {s.catalog_name}.{s.schema_name}", not miss, f"missing={miss}")

no_tag = spark.sql(f"""
  SELECT t.table_catalog, t.table_schema, t.table_name FROM system.information_schema.tables t
  LEFT JOIN (SELECT catalog_name, schema_name, table_name,
                    max(CASE WHEN tag_name='data_domain' THEN 1 END) dd,
                    max(CASE WHEN tag_name='data_classification' THEN 1 END) dc
             FROM system.information_schema.table_tags GROUP BY 1,2,3) g
    ON t.table_catalog=g.catalog_name AND t.table_schema=g.schema_name AND t.table_name=g.table_name
  WHERE t.table_catalog LIKE '{P}%_{ENV}' AND t.table_schema<>'information_schema' AND (g.dd IS NULL OR g.dc IS NULL)""")
check("UC-020", "Tables carry data_domain + data_classification", no_tag.count() == 0, no_tag.count())

no_cmt = spark.sql(f"""SELECT table_catalog, table_schema, table_name FROM system.information_schema.tables
  WHERE table_catalog IN ('{CAT['silver']}','{CAT['gold']}') AND table_schema<>'information_schema' AND (comment IS NULL OR trim(comment)='')""")
check("UC-021", "Silver/Gold tables have comments", no_cmt.count() == 0, no_cmt.count())

# COMMAND ----------

# MAGIC %md ## 5. Negative security – UC-006, UC-012, STG-008 (run as tester, NOT as admin)

# COMMAND ----------

def expect_denied(tc, desc, sql_or_fn):
    try:
        sql_or_fn() if callable(sql_or_fn) else spark.sql(sql_or_fn).collect()
        check(tc, desc, False, "executed – expected denial")
    except Exception as e:
        check(tc, desc, True, str(e).split("\n")[0][:160])

if ENV != "prod":
    expect_denied("UC-006", "PROD catalog not reachable from this workspace", f"SELECT 1 FROM {P}_bronze_prod.information_schema.tables LIMIT 1")
expect_denied("UC-012", "CREATE TABLE ... LOCATION denied",
              f"CREATE TABLE {CAT['bronze']}.{BRZ.split('.')[1]}.zz_smoke_ext (id INT) LOCATION 'abfss://bronze@stodsbronzegcp{ENV}weu.dfs.core.windows.net/zz_smoke_ext'")
expect_denied("STG-008", "Direct abfss listing of bronze storage denied",
              lambda: dbutils.fs.ls(f"abfss://bronze@stodsbronzegcp{ENV}weu.dfs.core.windows.net/"))

# COMMAND ----------

# MAGIC %md ## 6. Bronze – BRZ-002..006, BRZ-009, BRZ-011, BRZ-012

# COMMAND ----------

b = spark.table(BRZ)
print("Bronze columns:", b.columns)
# Adjust names to the framework's technical columns (Q-09)
TECH = ["_arrival_ts", "_source_system", "_run_id", "_env"]
miss = [c for c in TECH if c not in b.columns]
check("BRZ-004", "Technical columns present", not miss, f"missing={miss}")
for c in [c for c in TECH if c in b.columns]:
    n = b.filter(f"{c} IS NULL").count(); check("BRZ-004", f"{c} not null", n == 0, n)
if "_env" in b.columns:
    bad = b.filter(f"_env <> '{ENV}'").count(); check("BRZ-004", "_env equals widget env", bad == 0, bad)
if "_rescued_data" in b.columns:
    print("Rescued rows (BRZ-005):", b.filter("_rescued_data IS NOT NULL").count())
print("Rows per run (BRZ-002/006/007):"); display(b.groupBy("_run_id").count().orderBy("_run_id") if "_run_id" in b.columns else b.selectExpr("count(*)"))

# COMMAND ----------

k = spark.table(KAF)
pc = next((c for c in k.columns if c.lower() in ("kafka_partition", "_kafka_partition", "partition")), None)
oc = next((c for c in k.columns if c.lower() in ("kafka_offset", "_kafka_offset", "offset")), None)
if pc and oc:
    d = k.groupBy(pc, oc).count().filter("count > 1").count()
    check("BRZ-009", "Kafka partition+offset unique", d == 0, d)
    display(k.groupBy(pc).agg({oc: "min", "*": "count"}).withColumnRenamed(f"min({oc})", "min_offset"))
    display(k.groupBy(pc).agg({oc: "max"}))   # BRZ-012: (max-min+1) per partition should equal count when no gaps/compaction
else:
    check("BRZ-009", "Kafka coordinate columns found", False, k.columns)
print("Struct/array columns (ARCH_10 level-2 kept):", [f.name for f in k.schema.fields if f.dataType.typeName() in ("struct", "array")])

# COMMAND ----------

# BRZ-011 / UC-014: checkpoint volume
vols = spark.sql(f"SELECT volume_schema, volume_name, volume_type FROM {CAT['bronze']}.information_schema.volumes").toPandas()
display(vols); check("UC-014", "Checkpoint volume(s) present in bronze", len(vols) > 0, len(vols))

# COMMAND ----------

# MAGIC %md ## 7. Silver – SLV-002..004, SLV-006, SLV-007

# COMMAND ----------

s = spark.table(SLV); cols = [c.lower() for c in s.columns]; base = SLV.split(".")[-1]
sk, hk = f"{base}_key", f"{base}_hkey"
if sk in cols:
    n, dn = s.count(), s.select(sk).distinct().count(); nn = s.filter(f"{sk} IS NULL").count()
    check("SLV-002", f"{sk} unique & not null", n == dn and nn == 0, f"rows={n} distinct={dn} nulls={nn}")
    ddl = spark.sql(f"SHOW CREATE TABLE {SLV}").first()[0]
    check("SLV-002", f"{sk} is IDENTITY", "GENERATED" in ddl.upper() and "IDENTITY" in ddl.upper())
else:
    check("SLV-002", f"{sk} column exists", False, s.columns)
check("SLV-003", f"{hk} column exists", hk in cols)
if {"valid_from", "valid_to"} <= set(cols):
    spark.table(SLV).createOrReplaceTempView("slv")
    ov = spark.sql(f"""SELECT count(*) FROM slv a JOIN slv b ON a.{BK}=b.{BK} AND a.{sk}<>b.{sk}
                       AND a.valid_from < coalesce(b.valid_to, '9999-12-31') AND b.valid_from < coalesce(a.valid_to,'9999-12-31')""").first()[0]
    check("SLV-004", "No overlapping SCD2 intervals", ov == 0, ov)
    cur = spark.sql(f"""SELECT count(*) FROM (SELECT {BK} FROM slv WHERE valid_to IS NULL OR valid_to >= '9999-12-31'
                        GROUP BY {BK} HAVING count(*) <> 1)""").first()[0]
    check("SLV-004", "Exactly one current row per key", cur == 0, cur)
if "source_system" in cols:
    display(s.groupBy("source_system").count())

# COMMAND ----------

# SLV-007 / BRZ-006: idempotency fingerprint – run BEFORE and AFTER re-running the job, compare outputs
def fingerprint(t):
    return spark.sql(f"SELECT count(*) AS n, sum(xxhash64(*)) AS h FROM {t}").first()
for t in [BRZ, SLV, GLD]:
    try: print(t, fingerprint(t))
    except Exception as e: print(t, "ERR", e)

# COMMAND ----------

# MAGIC %md ## 8. Lineage, audit, jobs, billing – UC-024, OBS-002, OBS-003, OBS-005

# COMMAND ----------

display(spark.sql(f"""SELECT source_table_full_name, target_table_full_name, max(event_time) last_seen
  FROM system.access.table_lineage WHERE target_table_full_name IN ('{SLV}','{GLD}') AND event_date >= current_date()-7 GROUP BY 1,2"""))
display(spark.sql("""SELECT event_time, user_identity.email, service_name, action_name, response.status_code
  FROM system.access.audit WHERE event_date = current_date() ORDER BY event_time DESC LIMIT 100"""))
display(spark.sql("""SELECT job_id, run_id, period_start_time, period_end_time, result_state
  FROM system.lakeflow.job_run_timeline WHERE period_start_time >= current_date()-2 ORDER BY period_start_time DESC LIMIT 100"""))
untagged = spark.sql("""SELECT count(*) FROM system.billing.usage WHERE usage_date >= current_date()-2
  AND (custom_tags['cost_center'] IS NULL OR custom_tags['environment'] IS NULL)""").first()[0]
check("OBS-005", "No untagged DBU usage (last 2 days)", untagged == 0, untagged)

# COMMAND ----------

# MAGIC %md ## 9. Summary – copy into Test Cases sheet (Actual Result / Status)

# COMMAND ----------

display(spark.createDataFrame(results, "tc string, check string, result string, detail string"))

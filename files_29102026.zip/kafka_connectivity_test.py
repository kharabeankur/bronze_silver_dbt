# Databricks notebook source
# MAGIC %md
# MAGIC # Kafka connectivity test (step ladder)
# MAGIC
# MAGIC Goal of the session: can we **reach** Kafka and **authenticate**?
# MAGIC
# MAGIC The test climbs one rung at a time, so the first failing rung tells you where the problem is:
# MAGIC
# MAGIC 1. DNS: do the broker names resolve?
# MAGIC 2. TCP: is the port open from this cluster?
# MAGIC 3. TLS: does the TLS handshake work, and is the server certificate trusted by default?
# MAGIC 4. Credentials: can the secrets be read from Key Vault (names only, values never shown)?
# MAGIC 5. Kafka login: does Kafka accept the credentials and know the topic? (no messages are read)
# MAGIC 6. Optional: read a few messages (only the count is shown)
# MAGIC 7. Schema Registry: reachable?
# MAGIC
# MAGIC Safety: message content and secret values are never printed. If you type credentials in by hand
# MAGIC (MANUAL = True) they sit in notebook widgets: use that only interactively as a last resort,
# MAGIC then run the last cell to remove them and ask for the credentials to be rotated afterwards.

# COMMAND ----------

import json
import socket
import ssl
import time
from datetime import datetime, timezone

# COMMAND ----------

# ───────────── EDIT THIS CELL IN THE SESSION ─────────────

# TEST brokers and Schema Registry from the Sources document (Kafka has no DEV environment)
BROKERS = [
    "czsmsgkafbt1.cpas.cz:9093",
    "czsmsgkafbt2.cpas.cz:9093",
    "czsmsgkafbt3.cpas.cz:9093",
]
SCHEMA_REGISTRY_URL = "https://czsmsgkafbt1.cpas.cz:18082"
TOPIC = "<topic-name>"                  # ask which TEST topic to use

# How do we log in? Ask the Kafka team.
#   "ssl_files" = certificate login with truststore/keystore files (JKS or PKCS12)
#   "sasl"      = username/password over TLS
#   "none"      = only run the network rungs 1-3
AUTH_MODE = "ssl_files"

SECRET_SCOPE = "czlake-kv-scope"        # Key Vault-backed scope seen in the workspace

# --- AUTH_MODE = "ssl_files" ---
# On a STANDARD access mode cluster these two paths must be in a Unity Catalog
# volume or external location (Databricks documents this restriction).
TRUSTSTORE_PATH = "<e.g. /Volumes/<catalog>/<schema>/<volume>/kafka/truststore.jks>"
KEYSTORE_PATH = "<e.g. /Volumes/<catalog>/<schema>/<volume>/kafka/keystore.jks>"
STORE_TYPE = "JKS"                      # or PKCS12
TRUSTSTORE_PASSWORD_SECRET = "<secret-name>"
KEYSTORE_PASSWORD_SECRET = "<secret-name>"
KEY_PASSWORD_SECRET = "<secret-name>"   # often the same as the keystore password

# --- AUTH_MODE = "sasl" ---
SASL_MECHANISM = "PLAIN"                # PLAIN or SCRAM-SHA-512 ...
SASL_USER_SECRET = "<secret-name>"
SASL_PASSWORD_SECRET = "<secret-name>"

# Last resort when Key Vault does not work: values come from widgets instead of secrets.
MANUAL = False

READ_SAMPLE = False                     # rung 6: read a few recent messages (count only)
LOOKBACK_HOURS = 24
SAMPLE_MESSAGES = 10

# COMMAND ----------

# --- helpers: secrets, redaction, results -------------------------------------

SECRET_VALUES = set()
RESULTS = []


class Skip(Exception):
    """Rung not applicable yet (setting missing or optional step switched off)."""


def _widget(name):
    try:
        dbutils.widgets.text(name, "")
        return dbutils.widgets.get(name)
    except Exception:
        return ""


def get_secret(name):
    """Read from Key Vault (or from a widget when MANUAL). Remember the value so it can be redacted."""
    if MANUAL:
        value = _widget(f"manual_{name}")
    else:
        value = dbutils.secrets.get(SECRET_SCOPE, name)
    if not value:
        raise ValueError(f"secret '{name}' is empty or missing")
    SECRET_VALUES.add(value)
    return value


def redact(text):
    text = str(text)
    for s in SECRET_VALUES:
        if s and s in text:
            text = text.replace(s, "[REDACTED]")
    return text


def unset(**values):
    return [k for k, v in values.items() if v in (None, "") or "<" in str(v)]


HINTS = [
    ("Name or service not known", "DNS cannot resolve the host: private DNS / private endpoint is probably not set up for this workspace."),
    ("Temporary failure in name resolution", "DNS cannot resolve the host: private DNS / private endpoint is probably not set up for this workspace."),
    ("timed out", "Port does not answer: firewall, route or private endpoint is missing. Send the host and port to the network team."),
    ("Connection refused", "Host is reachable but nothing listens on that port: check the port number."),
    ("PKIX path building failed", "The server certificate is not trusted. Add the issuing CA to the truststore."),
    ("SSLHandshakeException", "TLS handshake failed: CA not trusted (truststore) or client certificate rejected (keystore)."),
    ("No subject alternative names", "Host name does not match the certificate. Check the broker names used."),
    ("keystore was tampered", "Wrong keystore/truststore password (or wrong file type)."),
    ("password was incorrect", "Wrong keystore/truststore password."),
    ("FileNotFoundException", "Keystore/truststore path is wrong or not readable."),
    ("NoSuchFileException", "Keystore/truststore path is wrong or not readable."),
    ("external location", "Standard access mode: certificate files must be in a Unity Catalog volume or external location."),
    ("SaslAuthenticationException", "Kafka rejected the username/password or the SASL mechanism."),
    ("TopicAuthorizationException", "Login worked, but this user is not allowed to read the topic (ACL)."),
    ("GroupAuthorizationException", "Login worked, but the consumer group is not allowed."),
    ("UnknownTopicOrPartition", "Topic name is wrong, or not visible to this user."),
    ("TimeoutException", "No answer from Kafka: network/firewall, wrong port, or TLS stuck."),
    ("Failed to construct kafka consumer", "Client configuration problem: read the first 'Caused by' line (often store path or password)."),
]


def explain(error_text):
    low = str(error_text).lower()
    for needle, hint in HINTS:
        if needle.lower() in low:
            return hint
    return "No known pattern. Send the full error text to the Kafka/platform team."


def step(rung, name, fn, requires=()):
    done = {r["rung"]: r["status"] for r in RESULTS}
    blocked = [f"{r}={done.get(r, 'NOT RUN')}" for r in requires if done.get(r) != "PASS"]
    t0 = time.time()
    if blocked:
        status, detail, hint = "SKIP", "Blocked by " + ", ".join(blocked), ""
    else:
        try:
            detail, hint, status = fn() or "", "", "PASS"
        except Skip as e:
            detail, hint, status = str(e), "", "SKIP"
        except Exception as e:  # noqa: BLE001 - keep climbing/reporting
            detail, status = redact(f"{type(e).__name__}: {str(e)[:600]}"), "FAIL"
            hint = explain(detail)
    RESULTS.append({"rung": rung, "name": name, "status": status,
                    "detail": redact(detail), "hint": hint, "secs": round(time.time() - t0, 1)})
    print(f"[{status:<4}] {rung}  {name} | {redact(detail)[:200]}")
    if hint:
        print(f"         -> {hint}")


# COMMAND ----------

# --- rungs 1-3: network -------------------------------------------------------

def hosts():
    return [(b.rsplit(":", 1)[0], int(b.rsplit(":", 1)[1])) for b in BROKERS]


def rung_dns():
    out = []
    for host, _ in hosts():
        ip = socket.getaddrinfo(host, None)[0][4][0]
        out.append(f"{host} -> {ip}")
    return "; ".join(out)


def rung_tcp():
    ok, bad = [], []
    for host, port in hosts():
        try:
            socket.create_connection((host, port), 10).close()
            ok.append(f"{host}:{port}")
        except Exception as e:  # noqa: BLE001
            bad.append(f"{host}:{port} ({type(e).__name__}: {e})")
    if bad:
        raise ConnectionError("not reachable: " + "; ".join(bad) + (f" | reachable: {ok}" if ok else ""))
    return f"all {len(ok)} broker ports open"


def rung_tls():
    host, port = hosts()[0]
    info = []
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE            # inspect only, trust is checked separately below
    with socket.create_connection((host, port), 10) as s:
        with ctx.wrap_socket(s, server_hostname=host) as t:
            info.append(f"{t.version()}")
            der = t.getpeercert(binary_form=True)
    try:
        from cryptography import x509
        cert = x509.load_der_x509_certificate(der)
        info.append(f"issuer={cert.issuer.rfc4514_string()[:80]}")
        info.append(f"expires={cert.not_valid_after:%Y-%m-%d}")
    except Exception:
        info.append("certificate details not available")
    try:                                       # is it trusted by the default CA store?
        strict = ssl.create_default_context()
        with socket.create_connection((host, port), 10) as s2:
            with strict.wrap_socket(s2, server_hostname=host):
                info.append("trusted by default CA store: yes")
    except Exception:
        info.append("trusted by default CA store: no (normal for a private CA, a truststore is needed)")
    return "; ".join(info)


step("1-DNS", "Broker names resolve", rung_dns)
step("2-TCP", "Broker ports are open", rung_tcp, requires=("1-DNS",))
step("3-TLS", "TLS handshake with first broker", rung_tls, requires=("2-TCP",))

# COMMAND ----------

# --- rung 4: credentials ------------------------------------------------------

def secret_names():
    if AUTH_MODE == "ssl_files":
        return {"truststore_password": TRUSTSTORE_PASSWORD_SECRET, "keystore_password": KEYSTORE_PASSWORD_SECRET,
                "key_password": KEY_PASSWORD_SECRET}
    if AUTH_MODE == "sasl":
        return {"user": SASL_USER_SECRET, "password": SASL_PASSWORD_SECRET}
    return {}


def rung_secrets():
    if AUTH_MODE == "none":
        raise Skip("AUTH_MODE is 'none': no credentials needed")
    missing = unset(**secret_names())
    if missing and not MANUAL:
        raise Skip("not configured yet - fill in: " + ", ".join(f"{m} secret name" for m in missing))
    if not MANUAL:
        scopes = [s.name for s in dbutils.secrets.listScopes()]
        if SECRET_SCOPE not in scopes:
            raise ValueError(f"scope '{SECRET_SCOPE}' not visible")
    names = list(secret_names().values()) if not MANUAL else [f for f in secret_names()]
    for n in names:
        get_secret(n)                           # value is never printed
    return f"{len(names)} credential value(s) retrieved from {'widgets (MANUAL)' if MANUAL else 'Key Vault'}"


step("4-SECRETS", "Credentials can be read", rung_secrets)

# COMMAND ----------

# --- rungs 5-6: Kafka login ---------------------------------------------------

def kafka_options():
    opts = {"kafka.bootstrap.servers": ",".join(BROKERS), "subscribe": TOPIC, "failOnDataLoss": "false"}
    if AUTH_MODE == "ssl_files":
        opts.update({
            "kafka.security.protocol": "SSL",
            "kafka.ssl.truststore.location": TRUSTSTORE_PATH,
            "kafka.ssl.truststore.type": STORE_TYPE,
            "kafka.ssl.truststore.password": get_secret(TRUSTSTORE_PASSWORD_SECRET if not MANUAL else "truststore_password"),
            "kafka.ssl.keystore.location": KEYSTORE_PATH,
            "kafka.ssl.keystore.type": STORE_TYPE,
            "kafka.ssl.keystore.password": get_secret(KEYSTORE_PASSWORD_SECRET if not MANUAL else "keystore_password"),
            "kafka.ssl.key.password": get_secret(KEY_PASSWORD_SECRET if not MANUAL else "key_password"),
        })
    elif AUTH_MODE == "sasl":
        user = get_secret(SASL_USER_SECRET if not MANUAL else "user")
        pwd = get_secret(SASL_PASSWORD_SECRET if not MANUAL else "password")
        module = ("org.apache.kafka.common.security.scram.ScramLoginModule" if "SCRAM" in SASL_MECHANISM
                  else "org.apache.kafka.common.security.plain.PlainLoginModule")
        opts.update({
            "kafka.security.protocol": "SASL_SSL",
            "kafka.sasl.mechanism": SASL_MECHANISM,
            "kafka.sasl.jaas.config": f'kafkashaded.{module} required username="{user}" password="{pwd}";',
        })
    else:
        raise ValueError("AUTH_MODE 'none' cannot log in")
    return opts


def rung_login():
    missing = unset(topic=TOPIC)
    if AUTH_MODE == "ssl_files":
        missing += unset(truststore_path=TRUSTSTORE_PATH, keystore_path=KEYSTORE_PATH)
    if AUTH_MODE == "none":
        raise Skip("AUTH_MODE is 'none': login not tested")
    if missing:
        raise Skip("not configured yet - fill in: " + ", ".join(missing))
    # latest..latest = connect, authenticate and read topic metadata, but consume no messages
    df = (spark.read.format("kafka").options(**kafka_options())
          .option("startingOffsets", "latest").option("endingOffsets", "latest").load())
    n = df.count()
    return f"connected, authenticated and found topic '{TOPIC}' (rows read: {n}, expected 0)"


def rung_sample():
    if not READ_SAMPLE:
        raise Skip("READ_SAMPLE is False (optional step)")
    start_ms = int((time.time() - LOOKBACK_HOURS * 3600) * 1000)
    df = (spark.read.format("kafka").options(**kafka_options())
          .option("startingTimestamp", str(start_ms)).option("endingOffsets", "latest").load()
          .limit(SAMPLE_MESSAGES))
    n = df.count()
    return f"read {n} message(s) from the last {LOOKBACK_HOURS}h (content not shown)"


step("5-LOGIN", "Kafka accepts the login and knows the topic", rung_login, requires=("3-TLS", "4-SECRETS"))
step("6-SAMPLE", "Read a few messages (optional)", rung_sample, requires=("5-LOGIN",))

# COMMAND ----------

# --- rung 7: Schema Registry --------------------------------------------------

def rung_registry():
    import requests
    resp = requests.get(SCHEMA_REGISTRY_URL.rstrip("/") + "/subjects", timeout=20)
    if resp.status_code in (401, 403):
        raise PermissionError(f"HTTP {resp.status_code}: reachable, but it needs credentials or a client certificate")
    resp.raise_for_status()
    return f"reachable, {len(resp.json())} subject(s) visible (names not shown)"


step("7-REGISTRY", "Schema Registry reachable", rung_registry, requires=("2-TCP",))

# COMMAND ----------

# --- summary ------------------------------------------------------------------

print("\n" + "=" * 78)
print(f"Kafka connectivity test - {datetime.now(timezone.utc):%Y-%m-%d %H:%M} UTC | auth mode: {AUTH_MODE}")
print("=" * 78)
for r in RESULTS:
    print(f"{r['status']:<5}{r['rung']:<11}{r['name']}")
    if r["status"] == "FAIL":
        print(f"      detail: {r['detail'][:300]}")
        print(f"      hint  : {r['hint']}")

first_fail = next((r for r in RESULTS if r["status"] == "FAIL"), None)
reach = all(r["status"] == "PASS" for r in RESULTS if r["rung"] in ("1-DNS", "2-TCP", "3-TLS"))
login = any(r["rung"] == "5-LOGIN" and r["status"] == "PASS" for r in RESULTS)
if login:
    OUTCOME = "REACHED AND AUTHENTICATED"
elif reach:
    OUTCOME = "REACHED, NOT YET AUTHENTICATED"
else:
    OUTCOME = "NOT REACHED"
print(f"\nOUTCOME: {OUTCOME}")
if first_fail:
    print(f"First failing rung: {first_fail['rung']} - {first_fail['hint']}")

# COMMAND ----------

# Run this cell at the end if you used MANUAL = True: removes the typed credentials from the widgets.
try:
    dbutils.widgets.removeAll()
    print("widgets removed - also clear this notebook's cell outputs and ask for the credentials to be rotated")
except Exception as e:  # noqa: BLE001
    print("could not remove widgets:", e)

# Databricks notebook source
# MAGIC %md
# MAGIC # Environment smoke test
# MAGIC
# MAGIC Validates the new Azure/Databricks environment before development starts:
# MAGIC
# MAGIC 1. Catalogs, managed locations, schema/table creation
# MAGIC 2. Landing and checkpoint storage read/write
# MAGIC 3. Key Vault-backed secrets
# MAGIC 4. Kafka (+ Schema Registry) -> Landing -> Bronze (Auto Loader)
# MAGIC 5. JDBC source -> timestamped Parquet in Landing
# MAGIC 6. Bronze -> Silver -> Gold with dummy data
# MAGIC 7. (optional) the real ingestion framework for one topic
# MAGIC
# MAGIC Safety rules built into this notebook:
# MAGIC * Sources are **read-only**. It never calls the Oracle cleanup procedures.
# MAGIC * Message payloads and table rows are **never printed or stored in results**.
# MAGIC * Secret values are redacted from every result before it is saved.
# MAGIC * Test tables and files are removed at the end. The `smoke_test` schema must already exist (schemas are
# MAGIC   platform-managed); it is only created, and dropped again, when `run.create_schema` is true.
# MAGIC * Writing to the layer catalogs may be allowed for service principals only: run it as a Job with the
# MAGIC   right run-as identity before judging CAT-W / FLOW results.
# MAGIC
# MAGIC Job parameters: `config_path` (YAML file), `environment` (label only).

# COMMAND ----------

import json
import os
import time
import uuid
from datetime import datetime, timezone

import yaml
from pyspark.sql import functions as F
from pyspark.sql.types import (
    BooleanType, DoubleType, StringType, StructField, StructType, TimestampType,
)

# COMMAND ----------

# --- HARNESS --- parameters and config -----------------------------------

def get_param(name, default):
    try:
        dbutils.widgets.text(name, default)
        return dbutils.widgets.get(name)
    except Exception:
        return default


def _notebook_dir():
    try:
        p = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
        d = os.path.dirname(p)
        return d if d.startswith("/Workspace") else "/Workspace" + d
    except Exception:
        return os.getcwd()


CONFIG_PATH = get_param("config_path", "smoke_test_config.yml")
if not os.path.isabs(CONFIG_PATH):
    CONFIG_PATH = os.path.join(_notebook_dir(), CONFIG_PATH)

with open(CONFIG_PATH) as f:
    CFG = yaml.safe_load(f)

ENV_LABEL = get_param("environment", CFG.get("environment", "dev"))
RUN_ID = uuid.uuid4().hex[:8]
STARTED = datetime.now(timezone.utc)
CLEANUP = bool(CFG.get("run", {}).get("cleanup", True))
SAMPLE_ROWS = int(CFG.get("run", {}).get("sample_rows", 5))
CREATE_SCHEMA = bool(CFG.get("run", {}).get("create_schema", False))   # schemas are platform-managed by default

print(f"config      : {CONFIG_PATH}")
print(f"environment : {ENV_LABEL}")
print(f"run id      : {RUN_ID}")

# COMMAND ----------

# --- HARNESS --- check runner, redaction, verdict, report -----------------

RESULTS = []
SECRET_VALUES = set()
CLEANUP_TABLES = []
CLEANUP_PATHS = []
CREATED_SCHEMAS = []
STATE = {}


class Skip(Exception):
    """Check not applicable (disabled in config)."""


class Warn(Exception):
    """Check worked but something deserves attention."""


def q(name):
    """Quote a SQL identifier."""
    return "`" + str(name).replace("`", "``") + "`"


def get_secret(scope, key):
    """Read a secret and remember its value so it can be redacted from output."""
    value = dbutils.secrets.get(scope, key)
    if value:
        SECRET_VALUES.add(value)
    return value


def redact(text):
    text = str(text)
    for s in SECRET_VALUES:
        if s and s in text:
            text = text.replace(s, "[REDACTED]")
    return text


def run_check(check_id, area, name, fn, critical=True, requires=()):
    """Run one check, never raise, record the result."""
    status_by_id = {r["check_id"]: r["status"] for r in RESULTS}
    blocked = [
        f"{r}={status_by_id.get(r, 'NOT RUN')}"
        for r in requires
        if status_by_id.get(r) not in ("PASS", "WARN")
    ]
    t0 = time.time()
    if blocked:
        status, detail = "SKIP", "Blocked by " + ", ".join(blocked)
    else:
        try:
            detail = fn() or ""
            status = "PASS"
        except Skip as e:
            status, detail = "SKIP", str(e)
        except Warn as e:
            status, detail = "WARN", str(e)
        except Exception as e:  # noqa: BLE001 - a smoke test must keep going
            status, detail = "FAIL", f"{type(e).__name__}: {str(e)[:500]}"
    detail = redact(detail)
    RESULTS.append({
        "check_id": check_id, "area": area, "name": name, "status": status,
        "critical": critical, "detail": detail,
        "duration_secs": round(time.time() - t0, 2),
        "executed_at": datetime.now(timezone.utc),
    })
    print(f"[{status:<4}] {check_id:<9} {name} | {detail[:160]}")


def verdict():
    crit_fail = [r for r in RESULTS if r["critical"] and r["status"] == "FAIL"]
    crit_skip = [r for r in RESULTS if r["critical"] and r["status"] == "SKIP"]
    warns = [r for r in RESULTS if r["status"] == "WARN"]
    if crit_fail:
        return "NOT READY"
    if crit_skip:
        return "INCOMPLETE"
    if warns:
        return "READY WITH WARNINGS"
    return "READY"


MANUAL_CHECKS = [
    ("Git integration enabled and repo connected", "Team / Marek with Lukas"),
    ("Who may edit compute; initial compute configuration captured", "Team with Lukas"),
    ("Enterprise access groups available (may only arrive next week)", "Open"),
    ("OneDrive / file-copy access (Lukas as workaround)", "Matej / Lukas"),
    ("Setup and results documented in Confluence", "Ankur"),
]
ICON = {"PASS": "PASS", "FAIL": "FAIL", "WARN": "WARN", "SKIP": "SKIP"}


def _cell(s):
    return str(s).replace("|", "\\|").replace("\n", " ")


def build_report_md():
    counts = {k: sum(1 for r in RESULTS if r["status"] == k) for k in ICON}
    lines = [
        f"# Smoke test report - {ENV_LABEL}",
        "",
        f"- Run id: `{RUN_ID}`",
        f"- Started (UTC): {STARTED:%Y-%m-%d %H:%M:%S}",
        f"- Verdict: **{verdict()}**",
        f"- PASS {counts['PASS']} | WARN {counts['WARN']} | "
        f"FAIL {counts['FAIL']} | SKIP {counts['SKIP']}",
        "",
        "## Automated checks",
        "",
        "| ID | Area | Check | Critical | Status | Detail |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    for r in RESULTS:
        lines.append(
            f"| {r['check_id']} | {_cell(r['area'])} | {_cell(r['name'])} | "
            f"{'yes' if r['critical'] else 'no'} | {r['status']} | {_cell(r['detail'])} |"
        )
    lines += ["", "## Manual checks (not automated)", "",
              "| Item | Owner | Result |", "| --- | --- | --- |"]
    for item, owner in MANUAL_CHECKS:
        lines.append(f"| {item} | {owner} | to be filled in |")
    return "\n".join(lines)

# COMMAND ----------

# --- CHECKS --- environment and catalogs ----------------------------------

CATS = CFG["catalogs"]
TEST_SCHEMA = CFG.get("test_schema", "smoke_test")
LANDING_BASE = CFG["paths"]["landing_base"].rstrip("/")
CHECKPOINT_BASE = CFG["paths"]["checkpoint_base"].rstrip("/")
LANDING_ROOT = f"{LANDING_BASE}/smoke_test/{RUN_ID}"
CHECKPOINT_ROOT = f"{CHECKPOINT_BASE}/smoke_test/{RUN_ID}"
CLEANUP_PATHS += [LANDING_ROOT, CHECKPOINT_ROOT]


def ensure_schema(cat):
    """Use the test schema if it exists; only create it when run.create_schema is true."""
    full = f"{q(cat)}.{q(TEST_SCHEMA)}"
    if spark.sql(f"SHOW SCHEMAS IN {q(cat)} LIKE '{TEST_SCHEMA}'").collect():
        return
    if not CREATE_SCHEMA:
        raise AssertionError(
            f"schema {cat}.{TEST_SCHEMA} does not exist. Schemas are platform-managed: "
            "ask for it to be created, or set run.create_schema: true")
    spark.sql(f"CREATE SCHEMA {full}")
    CREATED_SCHEMAS.append(full)


def unset(**values):
    """Names of settings that are still placeholders like <topic-name> (or empty)."""
    return [k for k, v in values.items() if v in (None, "") or "<" in str(v)]


def skip_if_unset(**values):
    missing = unset(**values)
    if missing:
        raise Skip("not configured yet - fill in: " + ", ".join(missing))


def check_env_info():
    user = spark.sql("SELECT current_user()").first()[0]
    wanted = {
        "cluster_id": "spark.databricks.clusterUsageTags.clusterId",
        "runtime": "spark.databricks.clusterUsageTags.sparkVersion",
        "node_type": "spark.databricks.clusterUsageTags.clusterNodeType",
        "access_mode": "spark.databricks.clusterUsageTags.dataSecurityMode",
    }
    info = {"user": user, "spark": spark.version}
    for label, key in wanted.items():
        try:
            info[label] = spark.conf.get(key)
        except Exception:
            info[label] = "n/a"
    return "; ".join(f"{k}={v}" for k, v in info.items())


def check_catalogs_exist():
    existing = {r[0].lower() for r in spark.sql("SHOW CATALOGS").collect()}
    missing = [c for c in CATS.values() if c.lower() not in existing]
    if missing:
        raise AssertionError(f"Missing catalogs: {missing}")
    return "found: " + ", ".join(sorted(CATS.values()))


def make_catalog_describe(cat):
    def _fn():
        rows = spark.sql(f"DESCRIBE CATALOG EXTENDED {q(cat)}").collect()
        try:
            return "; ".join(f"{r[0]}={r[1]}" for r in rows)[:400]
        except Exception:
            raise Warn("describe worked but output format was unexpected")
    return _fn


def make_crud(cat):
    def _fn():
        tbl = f"{q(cat)}.{q(TEST_SCHEMA)}.{q('crud_' + RUN_ID)}"
        ensure_schema(cat)
        spark.sql(f"CREATE TABLE {tbl} (id INT, note STRING, created_at TIMESTAMP)")
        CLEANUP_TABLES.append(tbl)
        try:
            spark.sql(f"INSERT INTO {tbl} VALUES (1,'a',current_timestamp()),(2,'b',current_timestamp())")
            n = spark.table(tbl).count()
            if n != 2:
                raise AssertionError(f"expected 2 rows, got {n}")
        finally:
            spark.sql(f"DROP TABLE IF EXISTS {tbl}")
        return "schema + managed table create/insert/read/drop OK"
    return _fn


run_check("ENV-01", "Environment", "Cluster, runtime and user info", check_env_info, critical=False)
run_check("CAT-01", "Catalogs", "Bronze/Silver/Gold/Meta catalogs exist", check_catalogs_exist)
for _layer, _cat in CATS.items():
    run_check(f"CAT-D-{_layer[:2].upper()}", "Catalogs", f"Describe catalog '{_cat}' (storage root / managed location)",
              make_catalog_describe(_cat), critical=False, requires=("CAT-01",))
for _layer, _cat in CATS.items():
    run_check(f"CAT-W-{_layer[:2].upper()}", "Catalogs", f"Create schema/table in '{_cat}'",
              make_crud(_cat), requires=("CAT-01",))

# COMMAND ----------

# --- CHECKS --- storage and Key Vault -------------------------------------

def make_path_rw(base, label):
    def _fn():
        skip_if_unset(**{f"paths.{label}_base": base})
        folder = f"{base}/smoke_test/{RUN_ID}/probe_{label}"
        probe = f"{folder}/probe.txt"
        dbutils.fs.put(probe, "smoke-test", True)
        got = dbutils.fs.head(probe)
        dbutils.fs.rm(folder, True)
        if got != "smoke-test":
            raise AssertionError("content read back does not match")
        return f"write/read/delete OK under {base}"
    return _fn


def check_parquet_landing():
    skip_if_unset(**{"paths.landing_base": LANDING_BASE})
    ts = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    path = f"{LANDING_ROOT}/parquet_probe_{ts}"
    df = spark.range(10).withColumn("loaded_at", F.current_timestamp())
    df.write.mode("overwrite").parquet(path)
    n = spark.read.parquet(path).count()
    if n != 10:
        raise AssertionError(f"expected 10 rows, got {n}")
    return "timestamped Parquet folder written and read back"


def check_secret_scope():
    scope = CFG["secrets"]["scope"]
    skip_if_unset(**{"secrets.scope": scope})
    names = [s.name for s in dbutils.secrets.listScopes()]
    if scope not in names:
        raise AssertionError(f"scope '{scope}' not visible (found {len(names)} scopes)")
    return f"scope '{scope}' visible"


def make_secret_read(key):
    def _fn():
        if "<" in key:
            raise Skip("placeholder secret name - replace it in the config")
        value = get_secret(CFG["secrets"]["scope"], key)
        if not value:
            raise AssertionError("secret is empty")
        return "retrieved (value not shown)"
    return _fn


run_check("STO-01", "Storage", "Landing path write/read/delete", make_path_rw(LANDING_BASE, "landing"))
run_check("STO-02", "Storage", "Checkpoint path write/read/delete", make_path_rw(CHECKPOINT_BASE, "checkpoint"))
run_check("STO-03", "Storage", "Timestamped Parquet write/read in Landing", check_parquet_landing,
          requires=("STO-01",))
run_check("SEC-01", "Key Vault", "Secret scope is visible", check_secret_scope)
for _i, _key in enumerate(CFG["secrets"].get("check_keys", []), start=1):
    run_check(f"SEC-{_i + 1:02d}", "Key Vault", f"Read secret '{_key}'", make_secret_read(_key),
              requires=("SEC-01",))

# COMMAND ----------

# --- CHECKS --- Kafka -> Landing -> Bronze --------------------------------

KS = CFG.get("kafka", {})


def kafka_options(topic):
    scope = CFG["secrets"]["scope"]
    opts = {
        "kafka.bootstrap.servers": KS["bootstrap_servers"],
        "subscribe": topic,
        "failOnDataLoss": "false",
    }
    mode = KS.get("auth_mode", "sasl_plain")
    if mode == "sasl_plain":
        user = get_secret(scope, KS["api_key_secret"])
        pwd = get_secret(scope, KS["api_secret_secret"])
        jaas = (f'{KS["jaas_class"]} required username="{user}" password="{pwd}";')
        opts.update({
            "kafka.security.protocol": "SASL_SSL",
            "kafka.sasl.mechanism": "PLAIN",
            "kafka.sasl.jaas.config": jaas,
        })
    elif mode == "ssl_cert":
        ssl = KS["ssl"]
        opts.update({
            "kafka.security.protocol": "SSL",
            "kafka.ssl.truststore.location": ssl["truststore_location"],
            "kafka.ssl.truststore.password": get_secret(scope, ssl["truststore_password_secret"]),
            "kafka.ssl.keystore.location": ssl["keystore_location"],
            "kafka.ssl.keystore.password": get_secret(scope, ssl["keystore_password_secret"]),
            "kafka.ssl.key.password": get_secret(scope, ssl["key_password_secret"]),
        })
    else:
        raise ValueError(f"unknown kafka.auth_mode '{mode}'")
    return opts


def kafka_sample_df():
    reader = spark.read.format("kafka").options(**kafka_options(KS["test_topic"]))
    lookback = KS.get("lookback_hours")
    if lookback:
        start_ms = int((time.time() - float(lookback) * 3600) * 1000)
        reader = reader.option("startingTimestamp", str(start_ms))
    else:
        reader = reader.option("startingOffsets", "earliest")
    reader = reader.option("endingOffsets", "latest")
    return reader.load().limit(int(KS.get("sample_messages", 20)))


def need_kafka():
    if not KS.get("enabled", False):
        raise Skip("kafka.enabled is false in config")
    req = {"kafka.bootstrap_servers": KS.get("bootstrap_servers"), "kafka.test_topic": KS.get("test_topic")}
    if KS.get("auth_mode", "sasl_plain") == "ssl_cert":
        for k, v in (KS.get("ssl") or {}).items():
            req[f"kafka.ssl.{k}"] = v
    else:
        req["kafka.api_key_secret"] = KS.get("api_key_secret")
        req["kafka.api_secret_secret"] = KS.get("api_secret_secret")
    skip_if_unset(**req)


def check_kafka_connect():
    need_kafka()
    n = len(kafka_sample_df().collect())   # payload is not printed or stored
    STATE["kafka_read_n"] = n
    if n == 0:
        raise Warn(f"connected to topic '{KS['test_topic']}' but no messages in the lookback window")
    return f"read {n} message(s) from '{KS['test_topic']}'"


def check_kafka_landing():
    need_kafka()
    if STATE.get("kafka_read_n", 0) == 0:
        raise Skip("no messages to land")
    ts = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    path = f"{LANDING_ROOT}/kafka_{ts}"
    df = kafka_sample_df().select(
        F.col("topic"), F.col("partition"), F.col("offset"),
        F.col("timestamp").alias("kafka_timestamp"),
        F.col("key").cast("string").alias("kafka_key"),
        F.col("value").alias("raw_bytes"),
        F.current_timestamp().alias("ingested_at"),
    )
    df.write.format("avro").mode("overwrite").save(path)
    n = spark.read.format("avro").load(path).count()
    STATE["kafka_landing_path"] = path
    STATE["kafka_landed_n"] = n
    if n == 0:
        raise AssertionError("Avro files written but nothing read back")
    return f"{n} message(s) written to Landing as Avro"


def check_kafka_bronze():
    need_kafka()
    src = STATE.get("kafka_landing_path")
    if not src:
        raise Skip("nothing in Landing to load")
    cat = CATS["bronze"]
    tbl = f"{q(cat)}.{q(TEST_SCHEMA)}.{q('kafka_' + RUN_ID)}"
    ensure_schema(cat)
    CLEANUP_TABLES.append(tbl)
    ck = f"{CHECKPOINT_ROOT}/kafka_bronze"
    stream = (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "avro")
        .option("cloudFiles.schemaLocation", f"{ck}/schema")
        .load(src)
        .writeStream
        .option("checkpointLocation", f"{ck}/cp")
        .trigger(availableNow=True)
        .toTable(tbl)
    )
    stream.awaitTermination()
    n = spark.table(tbl).count()
    if n != STATE["kafka_landed_n"]:
        raise AssertionError(f"Landing had {STATE['kafka_landed_n']} rows, Bronze has {n}")
    return f"Auto Loader loaded {n} row(s) into Bronze test table"


def check_schema_registry():
    need_kafka()
    sr = KS.get("schema_registry", {})
    if not sr.get("enabled", False):
        raise Skip("kafka.schema_registry.enabled is false in config")
    import requests
    cert = (sr["client_cert"], sr["client_key"]) if sr.get("client_cert") else None
    resp = requests.get(
        sr["url"].rstrip("/") + "/subjects",
        timeout=20, cert=cert, verify=sr.get("ca_bundle") or True,
    )
    resp.raise_for_status()
    return f"reachable, {len(resp.json())} subject(s) visible (names not shown)"


run_check("KAF-00", "Kafka", "Schema Registry reachable", check_schema_registry, critical=False)
run_check("KAF-01", "Kafka", "Connect and read sample messages", check_kafka_connect)
run_check("KAF-02", "Kafka", "Write messages to Landing (Avro)", check_kafka_landing, requires=("KAF-01", "STO-01"))
run_check("KAF-03", "Kafka", "Auto Loader: Landing -> Bronze", check_kafka_bronze, requires=("KAF-02", "CAT-W-BR"))

# COMMAND ----------

# --- CHECKS --- JDBC -> timestamped Parquet in Landing --------------------

JS = CFG.get("jdbc", {})


def jdbc_base_reader(conn):
    scope = CFG["secrets"]["scope"]
    return (
        spark.read.format("jdbc")
        .option("url", conn["url"])
        .option("user", get_secret(scope, conn["user_secret"]))
        .option("password", get_secret(scope, conn["password_secret"]))
        .option("driver", conn.get("driver", "oracle.jdbc.OracleDriver"))
    )


def need_jdbc(conn=None):
    if not JS.get("enabled", False):
        raise Skip("jdbc.enabled is false in config")
    if conn:
        skip_if_unset(**{f"jdbc.{conn['name']}.url": conn.get("url"),
                         f"jdbc.{conn['name']}.user_secret": conn.get("user_secret"),
                         f"jdbc.{conn['name']}.password_secret": conn.get("password_secret")})


def make_jdbc_ping(conn):
    def _fn():
        need_jdbc(conn)
        query = conn.get("ping_query", "SELECT 1 FROM DUAL")
        jdbc_base_reader(conn).option("query", query).load().first()
        return "connection and simple query OK"
    return _fn


def make_jdbc_table(conn, table):
    def _fn():
        need_jdbc(conn)
        query = f"SELECT * FROM {table} WHERE ROWNUM <= {SAMPLE_ROWS}"   # read-only
        df = jdbc_base_reader(conn).option("query", query).load()
        n = df.count()
        ts = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
        path = f"{LANDING_ROOT}/jdbc/{table.replace('.', '_').lower()}_{ts}"
        df.coalesce(1).write.mode("overwrite").parquet(path)
        back = spark.read.parquet(path).count()
        if back != n:
            raise AssertionError(f"read {n} rows but Parquet has {back}")
        if n == 0:
            raise Warn(f"{table} readable ({len(df.columns)} columns) but returned 0 rows")
        return f"{n} row(s), {len(df.columns)} column(s) written as timestamped Parquet"
    return _fn


for _c in JS.get("connections", []):
    _cid = _c["name"]
    run_check(f"JDBC-P-{_cid}", "JDBC", f"Connect to {_cid}", make_jdbc_ping(_c))
    for _t in _c.get("tables", []):
        run_check(f"JDBC-T-{_t}", "JDBC", f"Read {_t} -> Landing Parquet", make_jdbc_table(_c, _t),
                  requires=(f"JDBC-P-{_cid}", "STO-01"))
if not JS.get("connections"):
    run_check("JDBC-00", "JDBC", "At least one JDBC connection configured",
              lambda: (_ for _ in ()).throw(Skip("no JDBC connections in config")))

# COMMAND ----------

# --- CHECKS --- Bronze -> Silver -> Gold with dummy data -------------------

def check_medallion():
    sch = TEST_SCHEMA
    b = f"{q(CATS['bronze'])}.{q(sch)}.{q('flow_b_' + RUN_ID)}"
    s = f"{q(CATS['silver'])}.{q(sch)}.{q('flow_s_' + RUN_ID)}"
    g = f"{q(CATS['gold'])}.{q(sch)}.{q('flow_g_' + RUN_ID)}"
    for tbl in (b, s, g):
        CLEANUP_TABLES.append(tbl)

    spark.sql(f"CREATE TABLE {b} (id INT, grp STRING, amount DOUBLE, updated_at TIMESTAMP)")
    spark.sql(f"""
        INSERT INTO {b} VALUES
          (1,'A',10.0,TIMESTAMP'2026-01-01 10:00:00'),
          (1,'A',12.0,TIMESTAMP'2026-01-01 11:00:00'),
          (2,'B', 5.0,TIMESTAMP'2026-01-01 10:00:00'),
          (3,'A', 7.0,TIMESTAMP'2026-01-01 10:00:00')
    """)

    spark.sql(f"CREATE TABLE {s} (id INT, grp STRING, amount DOUBLE, updated_at TIMESTAMP)")
    spark.sql(f"""
        MERGE INTO {s} t
        USING (
          SELECT id, grp, amount, updated_at FROM (
            SELECT *, ROW_NUMBER() OVER (PARTITION BY id ORDER BY updated_at DESC) AS rn
            FROM {b}
          ) WHERE rn = 1
        ) u
        ON t.id = u.id
        WHEN MATCHED THEN UPDATE SET *
        WHEN NOT MATCHED THEN INSERT *
    """)
    if spark.table(s).count() != 3:
        raise AssertionError("Silver should hold 3 current rows (latest version per id)")
    latest = spark.sql(f"SELECT amount FROM {s} WHERE id = 1").first()[0]
    if latest != 12.0:
        raise AssertionError(f"Silver kept an old version for id=1 (amount={latest})")

    spark.sql(f"""
        CREATE TABLE {g} AS
        SELECT grp, SUM(amount) AS total_amount, COUNT(*) AS n
        FROM {s} GROUP BY grp
    """)
    totals = {r["grp"]: r["total_amount"] for r in spark.table(g).collect()}
    if totals != {"A": 19.0, "B": 5.0}:
        raise AssertionError(f"unexpected Gold totals: {totals}")
    return "Bronze -> Silver (MERGE, latest per key) -> Gold (aggregate) OK"


run_check("FLOW-01", "Medallion", "Dummy data Bronze -> Silver -> Gold", check_medallion,
          requires=("CAT-W-BR", "CAT-W-SI", "CAT-W-GO"))

# COMMAND ----------

# --- CHECKS --- optional: run the real framework for one topic -------------

FW = CFG.get("framework", {})


def make_framework_run(job_type):
    def _fn():
        if not FW.get("enabled", False):
            raise Skip("framework.enabled is false in config")
        out = dbutils.notebook.run(
            FW["notebook_path"],
            int(FW.get("timeout_seconds", 1800)),
            {
                "metadata_file": FW["metadata_file"],
                "environment": FW.get("environment", ENV_LABEL),
                "job_type": job_type,
            },
        )
        return f"framework '{job_type}' run finished ({str(out)[:100]})"
    return _fn


run_check("FW-01", "Framework", "Framework landing run (one topic)", make_framework_run("landing"), critical=False)
run_check("FW-02", "Framework", "Framework autoloader run (one topic)", make_framework_run("autoloader"),
          critical=False, requires=("FW-01",))

# COMMAND ----------

# --- CLEANUP, RESULTS, REPORT, VERDICT -------------------------------------

def cleanup():
    if not CLEANUP:
        print("cleanup disabled - test objects were left in place")
        return
    for tbl in CLEANUP_TABLES:
        try:
            spark.sql(f"DROP TABLE IF EXISTS {tbl}")
        except Exception as e:
            print(f"could not drop {tbl}: {redact(e)[:120]}")
    for s in CREATED_SCHEMAS:
        try:
            spark.sql(f"DROP SCHEMA IF EXISTS {s}")
        except Exception as e:
            print(f"could not drop schema {s}: {redact(e)[:120]}")
    for p in CLEANUP_PATHS:
        try:
            dbutils.fs.rm(p, True)
        except Exception as e:
            print(f"could not remove {p}: {redact(e)[:120]}")


def persist_results():
    meta_cat = CATS["meta"]
    tbl = f"{q(meta_cat)}.{q(TEST_SCHEMA)}.{q('smoke_test_results')}"
    ensure_schema(meta_cat)
    spark.sql(f"""
        CREATE TABLE IF NOT EXISTS {tbl} (
          run_id STRING, environment STRING, check_id STRING, area STRING,
          name STRING, status STRING, critical BOOLEAN, detail STRING,
          duration_secs DOUBLE, executed_at TIMESTAMP, executed_by STRING)
    """)
    user = spark.sql("SELECT current_user()").first()[0]
    schema = StructType([
        StructField("run_id", StringType()), StructField("environment", StringType()),
        StructField("check_id", StringType()), StructField("area", StringType()),
        StructField("name", StringType()), StructField("status", StringType()),
        StructField("critical", BooleanType()), StructField("detail", StringType()),
        StructField("duration_secs", DoubleType()), StructField("executed_at", TimestampType()),
        StructField("executed_by", StringType()),
    ])
    rows = [(RUN_ID, ENV_LABEL, r["check_id"], r["area"], r["name"], r["status"],
             r["critical"], r["detail"], float(r["duration_secs"]), r["executed_at"], user)
            for r in RESULTS]
    spark.createDataFrame(rows, schema).write.mode("append").saveAsTable(tbl)
    return tbl


def write_report(md):
    report_dir = CFG["paths"].get("report_dir", "")
    if not report_dir or "<" in report_dir:
        return None
    name = f"smoke_test_{ENV_LABEL}_{STARTED:%Y%m%d_%H%M%S}_{RUN_ID}.md"
    path = f"{report_dir.rstrip('/')}/{name}"
    dbutils.fs.put(path, md, True)
    return path


cleanup()

try:
    print("results saved to:", persist_results())
except Exception as e:
    print("WARNING - could not save results table:", redact(e)[:200])

REPORT_MD = build_report_md()
try:
    saved = write_report(REPORT_MD)
    print("report file:", saved or "not written (report_dir not configured)")
except Exception as e:
    print("WARNING - could not write report file:", redact(e)[:200])

print()
print(REPORT_MD)

# COMMAND ----------

FINAL = verdict()
print(f"\nVERDICT: {FINAL}")
if FINAL == "NOT READY":
    failed = [r["check_id"] for r in RESULTS if r["critical"] and r["status"] == "FAIL"]
    raise RuntimeError(f"Smoke test failed. Critical checks failed: {failed}")

dbutils.notebook.exit(json.dumps({"run_id": RUN_ID, "verdict": FINAL}))

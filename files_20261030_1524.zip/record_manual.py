"""Record manual confirmations from a laptop or CI and regenerate page, tracker and report.

    python tools/record_manual.py MAN-01 PASS "Git integration enabled, repo connected" --evidence "CONF-123"
    python tools/record_manual.py --file manual_entries.csv        # columns: tracker_id,status,note,evidence
    python tools/record_manual.py NET-01 PASS "firewall ticket closed" --by "Lukas" --no-publish
"""
import argparse
import csv
import getpass
import os
import sys
import types

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
from smoke_lib import core, manual, publish  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("tracker_id", nargs="?")
    ap.add_argument("status", nargs="?", choices=["PASS", "WARN", "FAIL", "SKIP", "NA"])
    ap.add_argument("note", nargs="?")
    ap.add_argument("--evidence")
    ap.add_argument("--by", default=getpass.getuser())
    ap.add_argument("--file", help="CSV with tracker_id,status,note,evidence")
    ap.add_argument("--environment", default="dev")
    ap.add_argument("--project-root", default=ROOT)
    ap.add_argument("--no-publish", action="store_true")
    a = ap.parse_args()
    entries = []
    if a.file:
        with open(a.file, newline="", encoding="utf-8") as f:
            entries += [(r["tracker_id"], r["status"], r["note"], r.get("evidence")) for r in csv.DictReader(f)]
    if a.tracker_id:
        if not (a.status and a.note):
            ap.error("tracker_id needs status and note")
        entries.append((a.tracker_id, a.status, a.note, a.evidence))
    if not entries:
        ap.error("nothing to record")
    params = {"environment": a.environment,
              "run_id": "manual-" + __import__("datetime").datetime.now(__import__("datetime").timezone.utc).strftime("%Y%m%d-%H%M%S")}
    dbutils = types.SimpleNamespace(widgets=types.SimpleNamespace(text=lambda *x: None, get=lambda k: params.get(k, "")),
                                    notebook=types.SimpleNamespace(entry_point=None))
    os.environ["SMOKE_FORCE_MANUAL"] = "1"
    ctx = core.init(None, dbutils, notebook="manual_cli", project_root=a.project_root)
    ctx.cfg.setdefault("publish", {})["on_close"] = "never" if a.no_publish else "always"
    rows = manual.tracker_rows(ctx)
    failed = 0
    for tid, status, note, ev in entries:
        try:
            manual.record_manual(ctx, tid, status, note, ev, by=a.by, rows=rows)
        except Exception as e:  # noqa: BLE001
            failed += 1
            print(f"NOT RECORDED {tid}: {e}")
    core.close()
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()

# Lakehouse smoke test – Databricks project

One Databricks Asset Bundle that proves the environment is ready, and documents itself while it runs:

* **`docs/SMOKE_TEST_RESULTS.md`** – rewritten after **every** check of every notebook and SQL file
* **`docs/Smoke_Test_Tracker.xlsx`** – Status / Date / Notes / Evidence filled from the results (task `publish`)
* **`docs/Smoke_Test_Report.docx`** + **`docs/SMOKE_TEST_REPORT.md`** – overall environment report (task `publish`)

## Layout

```
databricks.yml                  bundle: targets dev, test, prod
resources/smoke_test.job.yml    the job (12 tasks, see below)
config/smoke_test_config.yml    every setting; <...> = not known yet -> check is SKIPPED and named on the page
config/smoke_test_model.json    expected Bronze/Silver model (generated from the DDL)
src/smoke_lib/                  core (recorder), publish (page/tracker/report), env, kafka, synthetic, model_static
src/00 … 99 *.py                notebooks
sql/*.sql                       SQL readiness checks (header = id, expectation, severity)
dbt_smoke/                      dbt project used by 20_dbt_check
tools/generate_expected_model.py   DDL -> config/smoke_test_model.json
tools/desk_check.py             local checks without Databricks (also publishes)
tools/record_manual.py          record manual confirmations and regenerate everything
tools/publish_reports.py        regenerate page, tracker, report from the saved results
docs/                           results page, tracker, report, smoke_results/<run>/*.json
```

## How a result reaches the page, the tracker and the report

```
check function ──► core.run_check ──► docs/smoke_results/<run>/<notebook>.json   (immediately)
                                 └──► publish.render_results_md ──► docs/SMOKE_TEST_RESULTS.md   (after every check)
task 99_publish ──► publish.update_tracker ──► docs/Smoke_Test_Tracker.xlsx (+ sheet "Automated results", backup)
                └─► publish.build_report   ──► docs/Smoke_Test_Report.docx + docs/SMOKE_TEST_REPORT.md
```

* Every notebook starts with `core.init(...)` and ends with `core.close()`; nothing else is needed to appear on the page.
* Tracker rows are matched by exact ID, plus the regex map in `config/smoke_test_config.yml → tracker.map`
  (e.g. all `P12-*` checks fill row `FLOW-01`). Manual `N/A` and manual `Passed` are never overwritten.
* Two automated verdicts: **Databricks platform** (setup, catalogs, model, storage, secrets, pipeline, SQL,
  governance, dbt) and **Sources** (Kafka, Oracle, files). The report adds the tracker verdicts for development
  (gates 0–4) and UAT (gate 5). Desk-check results never count towards a verdict.
* Nothing sensitive is stored: secret values are redacted, payloads and rows are never written.

## The job

| Task | Notebook | Checks |
| --- | --- | --- |
| setup | 00_setup_test_environment | S00-01..08 – docs writable, catalogs, test schemas, run folders, secrets, identity, model, libraries |
| platform_checks | 01_platform_checks | CAT, MOD (model conformance), STO, SEC, KAF-00/01, JDBC (19 objects + columns vs model), FILE, DQ, FW |
| kafka_connectivity | 02_kafka_connectivity | KCT-1..7 ladder (DNS, TCP, TLS, secrets, login, sample, registry) |
| kafka_to_landing | 10_pipeline_kafka_to_landing | P10 – real Kafka or synthetic, raw Avro in Landing, Confluent framing |
| landing_to_bronze | 11_pipeline_landing_to_bronze | P11 – Auto Loader, decode, Bronze from model DDL, quarantine, idempotent |
| bronze_to_silver | 12_pipeline_bronze_to_silver | P12 – Silver Load_Pattern on smlouva / smlouva_hist from model DDL |
| silver_to_gold | 13_pipeline_silver_to_gold | P13 – dim_/fact_, reconciliation, managed, SQL warehouse read |
| dbt_check | 20_dbt_check | DBT-00..04 – version ≥ 1.9, snapshot with model meta columns, Gold, promotion test/prod |
| sql_checks | 30_sql_checks | every `sql/*.sql` (GOV-01/02/04/06/07, SQL-01..07) |
| governance_checks | 31_governance_checks | NET-04, GOV-03, KV-05, GOV-05 |
| cleanup | 98_cleanup | C98 – drops every `zz_smoke_*` object of the run (always runs) |
| publish | 99_publish | PUB – tracker and report (always runs) |
| *(by hand)* | 50_manual_checks | tracker IDs of manual items – recorded by a person |

`pipeline.source_mode: auto` uses real Kafka once `kafka.*` is complete, and model-shaped synthetic messages
(Confluent wire format, two batches, a redelivery, a corrupt message, a delete) until then – so the Databricks side
of Kafka → Landing → Bronze → Silver → Gold is proven now, independently of certificates and firewall rules.

## Run it

```bash
databricks bundle validate -t dev
databricks bundle deploy   -t dev
databricks bundle run      -t dev smoke_test          # job parameter environment = dev
# test (UAT) environment: same code, own workspace / catalogs gcp_dwhbi_all_*_test / service principal
databricks bundle deploy   -t test && databricks bundle run -t test smoke_test
```

Single notebooks can also be run interactively from a Git folder; they record into an `adhoc-…` run.

Locally, before anything is deployed:

```bash
python tools/generate_expected_model.py --bronze <06_Bronze_DDL.sql> --silver <15_Silver_DDL.sql> \
       --bronze-xlsx <11_….xlsx> --silver-xlsx <14_….xlsx> --out config/smoke_test_model.json
python tools/desk_check.py --environment dev --publish
```

### Where the docs are written – important with bundles

`databricks bundle deploy` uploads the local `docs/` folder and would overwrite a tracker that the job updated in
the workspace (`docs/smoke_results/` is excluded from sync). Two options:

1. **Recommended:** set `publish.docs_dir` to the team's **Git folder** in the workspace
   (e.g. `/Workspace/Users/<you>/lakehouse_smoke_test/docs`). The job writes there; commit and push from the Git UI.
2. Keep `docs` and download the files after each run; never deploy over them.

The job identity needs write access to that folder.

## Manual runs – the tracker and the report update themselves

Run any notebook by hand (Git folder, interactive cluster) and, when it finishes, `core.close()` regenerates
**all three documents**: results page, tracker and report. Inside the scheduled job only the final task
`99_publish` does this (`publish.on_close: auto`), so parallel tasks never write the workbook at the same time;
`docs/.publish.lock` serialises manual runs that overlap.

| You want to … | In Databricks | On a laptop / CI |
| --- | --- | --- |
| run one notebook and update everything | run the notebook (e.g. `12_pipeline_bronze_to_silver`) | – |
| run selected SQL files | `30_sql_checks` with widget `files` = `GOV-01*,SQL-03*` | – |
| record something a person checked | `50_manual_checks` (widgets or the `ENTRIES` list) | `python tools/record_manual.py MAN-01 PASS "Git integration enabled" --evidence CONF-123` |
| record many manual items | `ENTRIES` list in `50_manual_checks` | `python tools/record_manual.py --file entries.csv` (tracker_id,status,note,evidence) |
| just regenerate page, tracker and report | run `99_publish` | `python tools/publish_reports.py [--environment test] [--only tracker]` |
| check config / model / SQL / dbt before deploying | – | `python tools/desk_check.py --publish` |

Manual entries use the tracker row's own ID (MAN-01, NET-01, GOV-08 …) and the status PASS, WARN, FAIL, SKIP or
NA (= not applicable, sets the row to N/A). They appear in their own section on the results page and in the report,
and – unlike automated results – they may change a row a person had set before. Unknown IDs are rejected.

The tracker always shows the **latest result of each check across all runs** of the environment, so a manual
re-run of one notebook updates only its own rows.

## Add a check

* SQL: add `sql/<ID>_<name>.sql` with the header (see `sql/README.md`). Nothing else.
* Python: inside any notebook, `run_check("ID", "Area", "Name", fn, critical=..., requires=(...))`.
* Tracker: if the ID is not a tracker row, add a row or a regex in `tracker.map`; unmapped IDs are listed by PUB-02.

## Test status of this kit

* Verified here without Databricks: library (recorder, cross-notebook state and dependencies, page, tracker
  mapping, report), all notebooks executed end-to-end against a mocked Spark/dbutils, SQL file headers,
  dbt project structure, the expected-model generator (773 Bronze / 851 Silver columns match the model).
* **Not yet executed on Databricks:** Spark SQL statements, Avro encode/decode of the synthetic messages,
  Auto Loader + `foreachBatch`, the Silver MERGE statements and the dbt snapshot. Expect small fixes in the
  first real run; every failure lands on the results page with the exact error.

"""Regenerate the results page, the tracker and the report from the saved results – any time, anywhere.

    python tools/publish_reports.py                       # page + tracker + report, environment dev
    python tools/publish_reports.py --environment test
    python tools/publish_reports.py --only page           # page | tracker | report (repeatable)
    python tools/publish_reports.py --docs-dir /path/to/docs

In Databricks: run notebook src/99_publish.py by hand, or from a notebook cell:
    %run ./99_publish
Nothing is executed against Spark: everything is read from docs/smoke_results/<run>/*.json.
"""
import argparse
import os
import sys
import types

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
from smoke_lib import core, publish  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--environment", default="dev")
    ap.add_argument("--project-root", default=ROOT)
    ap.add_argument("--docs-dir")
    ap.add_argument("--only", action="append", choices=["page", "tracker", "report"])
    a = ap.parse_args()
    params = {"environment": a.environment, "run_id": "publish-" + __import__("datetime").datetime.now(__import__("datetime").timezone.utc).strftime("%Y%m%d-%H%M%S")}
    dbutils = types.SimpleNamespace(widgets=types.SimpleNamespace(text=lambda *x: None, get=lambda k: params.get(k, "")),
                                    notebook=types.SimpleNamespace(entry_point=None))
    ctx = core.init(None, dbutils, notebook="publish_cli", project_root=a.project_root)
    if a.docs_dir:
        ctx.docs_dir = a.docs_dir
        ctx.results_root = os.path.join(a.docs_dir, "smoke_results")
    # the CLI itself is not a run: remove the empty run folder init() created
    try:
        import shutil
        shutil.rmtree(os.path.join(ctx.results_root, ctx.run_id))
    except Exception:  # noqa: BLE001
        pass
    runs = [r for r in publish.list_runs(ctx) if r.get("environment") == a.environment]
    if runs:
        ctx.run_id = runs[0]["run_id"]
    only = set(a.only or ["page", "tracker", "report"])
    with publish.PublishLock(ctx):
        if "page" in only:
            print("page   :", publish.render_results_md(ctx))
        if "tracker" in only:
            r = publish.update_tracker(ctx)
            print("tracker:", r["path"], f"({len(r['changed'])} change(s), unmapped {r['unmapped']})")
        if "report" in only:
            print("report :", *publish.build_report(ctx))


if __name__ == "__main__":
    main()

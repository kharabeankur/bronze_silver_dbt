# Databricks notebook source
# MAGIC %md
# MAGIC # 50 · Record manual checks
# MAGIC
# MAGIC For tracker items a person verifies (Git integration, who may edit compute, enterprise groups, firewall
# MAGIC confirmations, Confluence documentation, sign-off …). Each entry is recorded under the **tracker row's ID**,
# MAGIC appears on `docs/SMOKE_TEST_RESULTS.md`, and – because this notebook is run by hand – the **tracker and the
# MAGIC report are regenerated when it finishes**.
# MAGIC
# MAGIC Two ways to use it:
# MAGIC 1. **Widgets** (one entry): fill `tracker_id`, `status`, `note`, `evidence` and run all.
# MAGIC 2. **List** (several entries): edit `ENTRIES` in the next cell and run all.
# MAGIC
# MAGIC Status: `PASS` · `WARN` (works, with a remark) · `FAIL` · `SKIP` (cannot be checked yet) · `NA` (not applicable).
# MAGIC Never type passwords or secret values into a note.

# COMMAND ----------

# Edit this list for several entries at once (leave empty to use the widgets only).
ENTRIES = [
    # ("MAN-01", "PASS", "Git integration enabled; repo lakehouse_smoke_test connected in Git folder", "Confluence page link"),
    # ("MAN-02", "PASS", "Only gcp-dbx-platform-admin may edit compute; initial config captured", "screenshot ref"),
    # ("NET-01", "PASS", "Network team confirmed dev subnets -> czsmsgkafbt1-3:9093 open", "ticket number"),
]

# COMMAND ----------

import os
import sys

sys.path.insert(0, os.getcwd())
from smoke_lib import core, manual  # noqa: E402

for name, default in (("tracker_id", ""), ("note", ""), ("evidence", "")):
    try:
        dbutils.widgets.text(name, default)
    except Exception:  # noqa: BLE001
        pass
try:
    dbutils.widgets.dropdown("status", "PASS", ["PASS", "WARN", "FAIL", "SKIP", "NA"])
except Exception:  # noqa: BLE001
    pass

ctx = core.init(spark, dbutils, notebook="50_manual_checks")
user = spark.sql("SELECT current_user()").first()[0]


def widget(name):
    try:
        return dbutils.widgets.get(name)
    except Exception:  # noqa: BLE001
        return ""


entries = list(ENTRIES)
if widget("tracker_id").strip():
    entries.append((widget("tracker_id").strip(), widget("status") or "PASS", widget("note"), widget("evidence") or None))
if not entries:
    print("Nothing to record: fill the widgets or ENTRIES. Publishing the current state anyway.")

rows = manual.tracker_rows(ctx)
for tid, status, note, evidence in entries:
    try:
        manual.record_manual(ctx, tid, status, note, evidence, by=user, rows=rows)
    except Exception as e:  # noqa: BLE001
        print(f"NOT RECORDED {tid}: {e}")

# COMMAND ----------

core.close()   # manual run -> results page, tracker and report are regenerated

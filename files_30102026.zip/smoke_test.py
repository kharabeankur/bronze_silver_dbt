# Databricks notebook source
# MAGIC %md
# MAGIC # Environment smoke test (model-aware, version 2)
# MAGIC
# MAGIC Validates the new Azure/Databricks environment before development starts:
# MAGIC
# MAGIC 1. Catalogs, managed locations, managed test table per layer (CAT)
# MAGIC 2. **Data model conformance** against `smoke_test_model.json`, generated from the Bronze/Silver DDL (MOD)
# MAGIC 3. Landing and checkpoint storage read/write (STO), Key Vault-backed secrets (SEC)
# MAGIC 4. Kafka (+ Schema Registry) -> Landing -> Bronze with the model's metadata columns (KAF)
# MAGIC 5. JDBC source -> timestamped Parquet in Landing, and source columns vs Bronze model (JDBC)
# MAGIC 6. Landing CSV files (KCC codelists, manual mapping) vs Bronze model, Auto Loader CSV (FILE)
# MAGIC 7. Bronze -> Silver -> Gold with dummy data using the **Silver load pattern** (hash keys, SCD2, soft delete) (FLOW)
# MAGIC 8. Data-quality rules on the real Bronze/Silver tables once they hold data (DQ)
# MAGIC 9. (optional) the real ingestion framework for one topic (FW)
# MAGIC
# MAGIC Safety rules built into this notebook:
# MAGIC * Sources are **read-only**. It never calls the Oracle cleanup procedures.
# MAGIC * Message payloads and table rows are **never printed or stored in results**.
# MAGIC * Secret values are redacted from every result before it is saved.
# MAGIC * Test objects are named `zz_smoke_<name>_<run id>` and dropped at the end. They go into the schema set by
# MAGIC   `test_schema` (one name, or one per layer). Schemas are platform-managed; one is only created, and
# MAGIC   dropped again, when `run.create_schema` is true.
# MAGIC * The real model tables are only **read** (information_schema, DESCRIBE DETAIL, counts). Never written.
# MAGIC * Writing to the layer catalogs may be allowed for service principals only: run it as a Job with the
# MAGIC   right run-as identity before judging CAT-W / FLOW results.
# MAGIC
# MAGIC Job parameters: `config_path` (YAML file), `environment` (label, also the expected `environment` tag value).
# MAGIC `smoke_test_model.json` must sit next to the config (see `model.expected_file`).

# COMMAND ----------

import json
import os
import re
import time
import uuid
from datetime import datetime, timezone

import yaml
from pyspark.sql import functions as F
from pyspark.sql.types import (
    BooleanType, DoubleType, StringType, StructField, StructType, TimestampType,
)

# COMMAND ----------

# --- HARNESS --- parameters and config -----------------------------------

def get_param(name, default):
    try:
        dbutils.widgets.text(name, default)
        return dbutils.widgets.get(name)
    except Exception:
        return default


def _notebook_dir():
    try:
        p = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
        d = os.path.dirname(p)
        return d if d.startswith("/Workspace") else "/Workspace" + d
    except Exception:
        return os.getcwd()


CONFIG_PATH = get_param("config_path", "smoke_test_config.yml")
if not os.path.isabs(CONFIG_PATH):
    CONFIG_PATH = os.path.join(_notebook_dir(), CONFIG_PATH)

with open(CONFIG_PATH) as f:
    CFG = yaml.safe_load(f)

ENV_LABEL = get_param("environment", CFG.get("environment", "dev"))
RUN_ID = uuid.uuid4().hex[:8]
STARTED = datetime.now(timezone.utc)
CLEANUP = bool(CFG.get("run", {}).get("cleanup", True))
SAMPLE_ROWS = int(CFG.get("run", {}).get("sample_rows", 5))
CREATE_SCHEMA = bool(CFG.get("run", {}).get("create_schema", False))   # schemas are platform-managed by default

print(f"config      : {CONFIG_PATH}")
print(f"environment : {ENV_LABEL}")
print(f"run id      : {RUN_ID}")

# COMMAND ----------

# --- HARNESS --- check runner, redaction, verdict, report -----------------

RESULTS = []
SECRET_VALUES = set()
CLEANUP_TABLES = []
CLEANUP_PATHS = []
CREATED_SCHEMAS = []
STATE = {}


class Skip(Exception):
    """Check not applicable (disabled in config)."""


class Warn(Exception):
    """Check worked but something deserves attention."""


def q(name):
    """Quote a SQL identifier."""
    return "`" + str(name).replace("`", "``") + "`"


def get_secret(scope, key):
    """Read a secret and remember its value so it can be redacted from output."""
    value = dbutils.secrets.get(scope, key)
    if value:
        SECRET_VALUES.add(value)
    return value


def redact(text):
    text = str(text)
    for s in SECRET_VALUES:
        if s and s in text:
            text = text.replace(s, "[REDACTED]")
    return text


def run_check(check_id, area, name, fn, critical=True, requires=()):
    """Run one check, never raise, record the result."""
    status_by_id = {r["check_id"]: r["status"] for r in RESULTS}
    blocked = [
        f"{r}={status_by_id.get(r, 'NOT RUN')}"
        for r in requires
        if status_by_id.get(r) not in ("PASS", "WARN")
    ]
    t0 = time.time()
    if blocked:
        status, detail = "SKIP", "Blocked by " + ", ".join(blocked)
    else:
        try:
            detail = fn() or ""
            status = "PASS"
        except Skip as e:
            status, detail = "SKIP", str(e)
        except Warn as e:
            status, detail = "WARN", str(e)
        except Exception as e:  # noqa: BLE001 - a smoke test must keep going
            status, detail = "FAIL", f"{type(e).__name__}: {str(e)[:500]}"
    detail = redact(detail)
    RESULTS.append({
        "check_id": check_id, "area": area, "name": name, "status": status,
        "critical": critical, "detail": detail,
        "duration_secs": round(time.time() - t0, 2),
        "executed_at": datetime.now(timezone.utc),
    })
    print(f"[{status:<4}] {check_id:<9} {name} | {detail[:160]}")


def verdict():
    crit_fail = [r for r in RESULTS if r["critical"] and r["status"] == "FAIL"]
    crit_skip = [r for r in RESULTS if r["critical"] and r["status"] == "SKIP"]
    warns = [r for r in RESULTS if r["status"] == "WARN"]
    if crit_fail:
        return "NOT READY"
    if crit_skip:
        return "INCOMPLETE"
    if warns:
        return "READY WITH WARNINGS"
    return "READY"


MANUAL_CHECKS = [
    ("Git integration enabled and repo connected", "Team / Marek with Lukas"),
    ("Who may edit compute; initial compute configuration captured", "Team with Lukas"),
    ("Enterprise access groups available (may only arrive next week)", "Open"),
    ("OneDrive / file-copy access (Lukas as workaround)", "Matej / Lukas"),
    ("Setup and results documented in Confluence", "Ankur"),
    ("dbt >= 1.9 (snapshot_meta_column_names) and one snapshot renamed correctly on dbt-databricks", "Team"),
    ("Which catalog names are right: DDL dbx_cz_gcz_dev_czlake_* vs workspace gcp_dwhbi_all_*_dev", "Lukas / modellers"),
]
ICON = {"PASS": "PASS", "FAIL": "FAIL", "WARN": "WARN", "SKIP": "SKIP"}


def _cell(s):
    return str(s).replace("|", "\\|").replace("\n", " ")


def build_report_md():
    counts = {k: sum(1 for r in RESULTS if r["status"] == k) for k in ICON}
    lines = [
        f"# Smoke test report - {ENV_LABEL}",
        "",
        f"- Run id: `{RUN_ID}`",
        f"- Started (UTC): {STARTED:%Y-%m-%d %H:%M:%S}",
        f"- Verdict: **{verdict()}**",
        f"- PASS {counts['PASS']} | WARN {counts['WARN']} | "
        f"FAIL {counts['FAIL']} | SKIP {counts['SKIP']}",
        "",
        "## Automated checks",
        "",
        "| ID | Area | Check | Critical | Status | Detail |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    for r in RESULTS:
        lines.append(
            f"| {r['check_id']} | {_cell(r['area'])} | {_cell(r['name'])} | "
            f"{'yes' if r['critical'] else 'no'} | {r['status']} | {_cell(r['detail'])} |"
        )
    lines += ["", "## Manual checks (not automated)", "",
              "| Item | Owner | Result |", "| --- | --- | --- |"]
    for item, owner in MANUAL_CHECKS:
        lines.append(f"| {item} | {owner} | to be filled in |")
    return "\n".join(lines)

# COMMAND ----------

# --- CHECKS --- environment and catalogs ----------------------------------

CATS = CFG["catalogs"]
LAYERS = [l for l in ("bronze", "silver", "gold", "meta") if l in CATS]
_TS = CFG.get("test_schema", "smoke_test")
TEST_PREFIX = CFG.get("run", {}).get("test_table_prefix", "zz_smoke_")
LANDING_BASE = CFG["paths"]["landing_base"].rstrip("/")
CHECKPOINT_BASE = CFG["paths"]["checkpoint_base"].rstrip("/")
LANDING_ROOT = f"{LANDING_BASE}/smoke_test/{RUN_ID}"
CHECKPOINT_ROOT = f"{CHECKPOINT_BASE}/smoke_test/{RUN_ID}"
CLEANUP_PATHS += [LANDING_ROOT, CHECKPOINT_ROOT]
HIGH_DATE = "TIMESTAMP'9999-12-31 00:00:00'"   # open SCD2 version (Silver model: high date, never NULL)


def test_schema(layer):
    """Schema that receives the test objects of a layer.

    test_schema may be one name for every catalog (e.g. smoke_test) or a map per layer, so that the
    test can use an existing, platform-managed schema (e.g. bronze: src_tia) until smoke_test exists.
    """
    if isinstance(_TS, dict):
        return _TS.get(layer) or _TS.get("default", "smoke_test")
    return _TS


def tname(layer, suffix):
    """Fully qualified name of a test table. Always prefixed and run-id suffixed, always dropped at the end."""
    return f"{q(CATS[layer])}.{q(test_schema(layer))}.{q(TEST_PREFIX + suffix + '_' + RUN_ID)}"


def ensure_schema(layer):
    """Use the test schema if it exists; only create it when run.create_schema is true."""
    cat, sch = CATS[layer], test_schema(layer)
    if "<" in str(sch):
        raise Skip(f"test_schema for {layer} is still a placeholder")
    if spark.sql(f"SHOW SCHEMAS IN {q(cat)} LIKE '{sch}'").collect():
        return
    if not CREATE_SCHEMA:
        raise AssertionError(
            f"schema {cat}.{sch} does not exist. Schemas are platform-managed: ask for it to be created, "
            "point test_schema.{layer} at an existing schema, or set run.create_schema: true")
    spark.sql(f"CREATE SCHEMA {q(cat)}.{q(sch)}")
    CREATED_SCHEMAS.append(f"{q(cat)}.{q(sch)}")


def unset(**values):
    """Names of settings that are still placeholders like <topic-name> (or empty)."""
    return [k for k, v in values.items() if v in (None, "") or "<" in str(v)]


def skip_if_unset(**values):
    missing = unset(**values)
    if missing:
        raise Skip("not configured yet - fill in: " + ", ".join(missing))


def scalar(sql):
    return spark.sql(sql).first()[0]


def check_env_info():
    user = spark.sql("SELECT current_user()").first()[0]
    wanted = {
        "cluster_id": "spark.databricks.clusterUsageTags.clusterId",
        "runtime": "spark.databricks.clusterUsageTags.sparkVersion",
        "node_type": "spark.databricks.clusterUsageTags.clusterNodeType",
        "access_mode": "spark.databricks.clusterUsageTags.dataSecurityMode",
    }
    info = {"user": user, "spark": spark.version}
    for label, key in wanted.items():
        try:
            info[label] = spark.conf.get(key)
        except Exception:
            info[label] = "n/a"
    return "; ".join(f"{k}={v}" for k, v in info.items())


def check_catalogs_exist():
    existing = {r[0].lower() for r in spark.sql("SHOW CATALOGS").collect()}
    missing = [c for c in CATS.values() if c.lower() not in existing]
    if missing:
        raise AssertionError(f"Missing catalogs: {missing}")
    return "found: " + ", ".join(sorted(CATS.values()))


def make_catalog_describe(cat):
    def _fn():
        rows = spark.sql(f"DESCRIBE CATALOG EXTENDED {q(cat)}").collect()
        try:
            return "; ".join(f"{r[0]}={r[1]}" for r in rows)[:400]
        except Exception:
            raise Warn("describe worked but output format was unexpected")
    return _fn


def make_crud(layer):
    def _fn():
        ensure_schema(layer)
        tbl = tname(layer, "crud")
        spark.sql(f"CREATE TABLE {tbl} (id INT, note STRING, created_at TIMESTAMP)")
        CLEANUP_TABLES.append(tbl)
        try:
            spark.sql(f"INSERT INTO {tbl} VALUES (1,'a',current_timestamp()),(2,'b',current_timestamp())")
            n = spark.table(tbl).count()
            if n != 2:
                raise AssertionError(f"expected 2 rows, got {n}")
            ttype = scalar(f"SELECT table_type FROM {q(CATS[layer])}.information_schema.tables "
                           f"WHERE table_schema = '{test_schema(layer)}' "
                           f"AND table_name = '{(TEST_PREFIX + 'crud_' + RUN_ID).lower()}'")
            if ttype != "MANAGED":
                raise AssertionError(f"table type is {ttype}, expected MANAGED")
        finally:
            spark.sql(f"DROP TABLE IF EXISTS {tbl}")
        return f"managed table create/insert/read/drop OK in {CATS[layer]}.{test_schema(layer)}"
    return _fn


run_check("ENV-01", "Environment", "Cluster, runtime and user info", check_env_info, critical=False)
run_check("CAT-01", "Catalogs", "Bronze/Silver/Gold/Meta catalogs exist", check_catalogs_exist)
for _layer, _cat in CATS.items():
    run_check(f"CAT-D-{_layer[:2].upper()}", "Catalogs", f"Describe catalog '{_cat}' (storage root / managed location)",
              make_catalog_describe(_cat), critical=False, requires=("CAT-01",))
for _layer, _cat in CATS.items():
    run_check(f"CAT-W-{_layer[:2].upper()}", "Catalogs", f"Create managed test table in '{_cat}.{test_schema(_layer)}'",
              make_crud(_layer), requires=("CAT-01",))

# COMMAND ----------

# --- CHECKS --- data model conformance (driven by smoke_test_model.json) ----
#
# smoke_test_model.json is generated from the Bronze/Silver DDL and physical models by
# generate_expected_model.py. The checks below compare the environment with the model:
# schemas, tags, tables, columns, keys, clustering, table properties. They are not critical for
# the development verdict: tables may legitimately not exist yet. A MISSING SCHEMA is critical,
# an EXTERNAL table is a failure (managed tables only).

MCFG = CFG.get("model", {})
MODEL = {}
REQUIRED_SCHEMA_TAGS = MCFG.get("required_schema_tags",
                                ["environment", "layer", "data_domain", "data_classification", "cost_center", "owner"])


def load_model():
    path = MCFG.get("expected_file", "smoke_test_model.json")
    if not os.path.isabs(path):
        path = os.path.join(os.path.dirname(CONFIG_PATH), path)
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def need_model(layer=None):
    if not MCFG.get("enabled", True):
        raise Skip("model.enabled is false in config")
    if not MODEL:
        raise Skip("smoke_test_model.json not loaded (see MOD-00)")
    if layer and not MODEL["layers"].get(layer, {}).get("schemas"):
        raise Skip(f"model has no {layer} objects ({MODEL['layers'].get(layer, {}).get('note', 'not delivered')})")


def ntype(t):
    t = re.sub(r"\bnot\s*null\b", "", str(t), flags=re.I)
    return re.sub(r"[\s`]", "", t).lower()


def check_model_loaded():
    if not MCFG.get("enabled", True):
        raise Skip("model.enabled is false in config")
    MODEL.update(load_model())
    parts = [f"{l}: {len(v['schemas'])} schemas / {len(v['tables'])} tables" for l, v in MODEL["layers"].items()]
    return f"generated {MODEL.get('generated_at')} | " + "; ".join(parts)


def check_model_static():
    """Defects that are visible in the model itself, before touching the workspace."""
    need_model()
    issues, warns = [], []
    for layer, ddl_cat in MODEL.get("ddl_catalogs", {}).items():
        if layer in CATS and ddl_cat and ddl_cat != CATS[layer]:
            issues.append(f"DDL targets catalog {ddl_cat} but this environment uses {CATS[layer]}")
    for layer, v in MODEL["layers"].items():
        for sch, meta in v["schemas"].items():
            env_tag = meta.get("tags", {}).get("environment")
            if env_tag and env_tag != ENV_LABEL:
                warns.append(f"{layer}.{sch} environment tag = '{env_tag}' (expected '{ENV_LABEL}')")
            if len(sch) > 22:
                issues.append(f"{layer}.{sch} longer than 22 characters")
            if not re.fullmatch(r"[a-z][a-z0-9_]*", sch):
                issues.append(f"{layer}.{sch} is not lower_snake_case ASCII")
        tables = v["tables"]
        for key, t in tables.items():
            if t.get("has_location"):
                issues.append(f"{layer}.{key} declares LOCATION (managed tables only)")
            for fk in t.get("foreign_keys", []):
                parent = tables.get(fk["parent"])
                if parent and fk["parent_columns"] != parent["primary_key"]:
                    issues.append(f"{fk['name']} references {fk['parent']}({', '.join(fk['parent_columns'])}) "
                                  f"which is not its primary key ({', '.join(parent['primary_key'])}): "
                                  "Unity Catalog will reject this ALTER TABLE")
    if issues:
        raise AssertionError(f"{len(issues)} model defect(s): " + " | ".join(issues[:8]) +
                             (f" | ... +{len(issues) - 8}" if len(issues) > 8 else "") +
                             (f" || also {len(warns)} warning(s)" if warns else ""))
    if warns:
        raise Warn(f"{len(warns)} warning(s): " + " | ".join(sorted(set(warns))[:6]))
    return "no static model defects"


def _info(layer, view, where=""):
    return spark.sql(f"SELECT * FROM {q(CATS[layer])}.information_schema.{view} {where}")


def make_schemas_check(layer):
    def _fn():
        need_model(layer)
        expected = set(MODEL["layers"][layer]["schemas"])
        present = {r.schema_name for r in _info(layer, "schemata").select("schema_name").collect()}
        missing = sorted(expected - present)
        extra = sorted(present - expected - {"information_schema", "default", test_schema(layer)})
        STATE[f"present_schemas_{layer}"] = present
        if missing:
            raise AssertionError(f"missing schema(s): {missing}" + (f"; not in model: {extra}" if extra else ""))
        if extra:
            raise Warn(f"all {len(expected)} model schemas present; also present but not in model: {extra}")
        return f"all {len(expected)} model schemas present"
    return _fn


def make_schema_tags_check(layer):
    def _fn():
        need_model(layer)
        rows = _info(layer, "schema_tags").collect()
        tags = {}
        for r in rows:
            tags.setdefault(r.schema_name, {})[r.tag_name] = r.tag_value
        problems = []
        for sch in MODEL["layers"][layer]["schemas"]:
            if sch not in STATE.get(f"present_schemas_{layer}", set()):
                continue
            have = tags.get(sch, {})
            miss = [t for t in REQUIRED_SCHEMA_TAGS if t not in have]
            if miss:
                problems.append(f"{sch}: missing {miss}")
            if have.get("environment") not in (None, ENV_LABEL):
                problems.append(f"{sch}: environment='{have.get('environment')}'")
            if have.get("layer") not in (None, layer):
                problems.append(f"{sch}: layer='{have.get('layer')}'")
        if problems:
            raise Warn(f"{len(problems)} tag issue(s): " + " | ".join(problems[:8]))
        return "mandatory schema tags present with correct environment and layer values"
    return _fn


def make_tables_check(layer):
    def _fn():
        need_model(layer)
        expected = MODEL["layers"][layer]["tables"]
        rows = _info(layer, "tables", "WHERE table_schema <> 'information_schema'").select(
            "table_schema", "table_name", "table_type", "data_source_format").collect()
        present = {f"{r.table_schema}.{r.table_name}": r for r in rows}
        STATE[f"present_tables_{layer}"] = present
        external = [k for k, r in present.items() if r.table_type == "EXTERNAL"]
        missing = sorted(k for k in expected if k not in present)
        wrong_type = [k for k in expected if k in present and present[k].table_type != "MANAGED"]
        not_delta = [k for k in expected if k in present and (present[k].data_source_format or "").upper() != "DELTA"]
        if external:
            raise AssertionError(f"{len(external)} EXTERNAL table(s) (managed tables only): {external[:6]}")
        msg = f"{len(expected) - len(missing)}/{len(expected)} model tables present"
        if wrong_type or not_delta:
            raise AssertionError(f"{msg}; not MANAGED: {wrong_type[:5]}; not DELTA: {not_delta[:5]}")
        if missing:
            raise Warn(f"{msg}; missing: {missing[:8]}" + (f" ... +{len(missing) - 8}" if len(missing) > 8 else ""))
        return msg + ", all MANAGED Delta"
    return _fn


def make_columns_check(layer):
    def _fn():
        need_model(layer)
        expected = MODEL["layers"][layer]["tables"]
        present = STATE.get(f"present_tables_{layer}") or {}
        todo = [k for k in expected if k in present]
        if not todo:
            raise Skip("no model table exists yet")
        cols = {}
        for r in _info(layer, "columns", "WHERE table_schema <> 'information_schema'").select(
                "table_schema", "table_name", "column_name", "full_data_type", "is_nullable").collect():
            cols.setdefault(f"{r.table_schema}.{r.table_name}", {})[r.column_name.lower()] = r
        issues, bad_tables = [], 0
        for k in todo:
            have, t_issues = cols.get(k, {}), []
            for c in expected[k]["columns"]:
                hc = have.get(c["name"].lower())
                if hc is None:
                    t_issues.append(f"missing {c['name']}")
                    continue
                if ntype(hc.full_data_type) != ntype(c["type"]):
                    t_issues.append(f"{c['name']} {hc.full_data_type} != {c['type'][:40]}")
                if c["not_null"] and hc.is_nullable == "YES":
                    t_issues.append(f"{c['name']} nullable")
            extra = set(have) - {c["name"].lower() for c in expected[k]["columns"]}
            if extra:
                t_issues.append(f"extra {sorted(extra)[:3]}")
            if t_issues:
                bad_tables += 1
                issues.append(f"{k}: " + ", ".join(t_issues[:3]))
        if issues:
            raise Warn(f"{bad_tables}/{len(todo)} table(s) differ from model: " + " | ".join(issues[:5]))
        return f"{len(todo)} table(s): columns, types and NOT NULL match the model"
    return _fn


def make_keys_check(layer):
    def _fn():
        need_model(layer)
        expected = MODEL["layers"][layer]["tables"]
        present = STATE.get(f"present_tables_{layer}") or {}
        todo = [k for k in expected if k in present]
        if not todo:
            raise Skip("no model table exists yet")
        kc = spark.sql(f"""
            SELECT tc.table_schema, tc.table_name, tc.constraint_type, tc.constraint_name,
                   concat_ws(',', array_sort(collect_list(k.column_name))) AS cols
            FROM {q(CATS[layer])}.information_schema.table_constraints tc
            JOIN {q(CATS[layer])}.information_schema.key_column_usage k
              ON tc.constraint_name = k.constraint_name AND tc.table_schema = k.table_schema
                 AND tc.table_name = k.table_name
            GROUP BY ALL""").collect()
        pk = {f"{r.table_schema}.{r.table_name}": r.cols for r in kc if r.constraint_type == "PRIMARY KEY"}
        fk = {(f"{r.table_schema}.{r.table_name}", r.constraint_name) for r in kc if r.constraint_type == "FOREIGN KEY"}
        issues = []
        for k in todo:
            want = ",".join(sorted(expected[k]["primary_key"]))
            if want and pk.get(k) != want:
                issues.append(f"{k}: PK {pk.get(k)} != {want}")
            for f in expected[k].get("foreign_keys", []):
                if (k, f["name"]) not in fk:
                    issues.append(f"{k}: FK {f['name']} missing")
        if issues:
            raise Warn(f"{len(issues)} key issue(s): " + " | ".join(issues[:6]))
        return f"{len(todo)} table(s): primary and foreign keys as in the model"
    return _fn


def make_detail_check(layer):
    def _fn():
        need_model(layer)
        expected = MODEL["layers"][layer]["tables"]
        present = STATE.get(f"present_tables_{layer}") or {}
        todo = [k for k in expected if k in present][: int(MCFG.get("max_detail_tables", 100))]
        if not todo:
            raise Skip("no model table exists yet")
        root = None
        try:
            d = {r[0]: r[1] for r in spark.sql(f"DESCRIBE CATALOG EXTENDED {q(CATS[layer])}").collect()}
            root = (d.get("Storage Root") or d.get("Storage Location") or "").rstrip("/") or None
        except Exception:
            pass
        issues = []
        for k in todo:
            sch, tbl = k.split(".")
            det = spark.sql(f"DESCRIBE DETAIL {q(CATS[layer])}.{q(sch)}.{q(tbl)}").first().asDict()
            want_cl = [c.lower() for c in expected[k]["cluster_by"]]
            have_cl = [c.lower() for c in (det.get("clusteringColumns") or [])]
            if want_cl and have_cl != want_cl:
                issues.append(f"{k}: cluster {have_cl} != {want_cl}")
            props = det.get("properties") or {}
            for p, v in expected[k]["properties"].items():
                if p.startswith("delta.") and str(props.get(p, "")).lower() != str(v).lower():
                    issues.append(f"{k}: {p}={props.get(p)} (model {v})")
            host = re.search(r"@([^/]+)", root or "")
            if host and det.get("location") and host.group(1) not in str(det["location"]):
                issues.append(f"{k}: location not on the catalog storage account {host.group(1)}")
        if issues:
            raise Warn(f"{len(issues)} issue(s): " + " | ".join(issues[:6]))
        return f"{len(todo)} table(s): clustering, Delta properties (CDF, column mapping) and location OK"
    return _fn


run_check("MOD-00", "Model", "Load expected model (smoke_test_model.json)", check_model_loaded, critical=False)
run_check("MOD-01", "Model", "Static model checks (catalog names, tags, FK targets, naming)", check_model_static,
          critical=False, requires=("MOD-00",))
for _layer in ("bronze", "silver", "gold"):
    if _layer not in CATS:
        continue
    _L = _layer[:2].upper()
    _crit = _layer in ("bronze", "silver") and MCFG.get("enabled", True)
    run_check(f"MOD-SCH-{_L}", "Model", f"{_layer.title()} schemas exist as modelled", make_schemas_check(_layer),
              critical=_crit, requires=("MOD-00", "CAT-01"))
    run_check(f"MOD-TAG-{_L}", "Model", f"{_layer.title()} schema tags", make_schema_tags_check(_layer),
              critical=False, requires=(f"MOD-SCH-{_L}",))
    run_check(f"MOD-TBL-{_L}", "Model", f"{_layer.title()} tables exist, MANAGED, Delta", make_tables_check(_layer),
              critical=False, requires=(f"MOD-SCH-{_L}",))
    run_check(f"MOD-COL-{_L}", "Model", f"{_layer.title()} columns and types match model", make_columns_check(_layer),
              critical=False, requires=(f"MOD-TBL-{_L}",))
    run_check(f"MOD-KEY-{_L}", "Model", f"{_layer.title()} primary/foreign keys", make_keys_check(_layer),
              critical=False, requires=(f"MOD-TBL-{_L}",))
    run_check(f"MOD-DET-{_L}", "Model", f"{_layer.title()} clustering, properties, location", make_detail_check(_layer),
              critical=False, requires=(f"MOD-TBL-{_L}",))

# COMMAND ----------

# --- CHECKS --- storage and Key Vault -------------------------------------

def make_path_rw(base, label):
    def _fn():
        skip_if_unset(**{f"paths.{label}_base": base})
        folder = f"{base}/smoke_test/{RUN_ID}/probe_{label}"
        probe = f"{folder}/probe.txt"
        dbutils.fs.put(probe, "smoke-test", True)
        got = dbutils.fs.head(probe)
        dbutils.fs.rm(folder, True)
        if got != "smoke-test":
            raise AssertionError("content read back does not match")
        return f"write/read/delete OK under {base}"
    return _fn


def check_parquet_landing():
    skip_if_unset(**{"paths.landing_base": LANDING_BASE})
    ts = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    path = f"{LANDING_ROOT}/parquet_probe_{ts}"
    df = spark.range(10).withColumn("loaded_at", F.current_timestamp())
    df.write.mode("overwrite").parquet(path)
    n = spark.read.parquet(path).count()
    if n != 10:
        raise AssertionError(f"expected 10 rows, got {n}")
    return "timestamped Parquet folder written and read back"


def check_secret_scope():
    scope = CFG["secrets"]["scope"]
    skip_if_unset(**{"secrets.scope": scope})
    names = [s.name for s in dbutils.secrets.listScopes()]
    if scope not in names:
        raise AssertionError(f"scope '{scope}' not visible (found {len(names)} scopes)")
    return f"scope '{scope}' visible"


def make_secret_read(key):
    def _fn():
        if "<" in key:
            raise Skip("placeholder secret name - replace it in the config")
        value = get_secret(CFG["secrets"]["scope"], key)
        if not value:
            raise AssertionError("secret is empty")
        return "retrieved (value not shown)"
    return _fn


run_check("STO-01", "Storage", "Landing path write/read/delete", make_path_rw(LANDING_BASE, "landing"))
run_check("STO-02", "Storage", "Checkpoint path write/read/delete", make_path_rw(CHECKPOINT_BASE, "checkpoint"))
run_check("STO-03", "Storage", "Timestamped Parquet write/read in Landing", check_parquet_landing,
          requires=("STO-01",))
run_check("SEC-01", "Key Vault", "Secret scope is visible", check_secret_scope)
for _i, _key in enumerate(CFG["secrets"].get("check_keys", []), start=1):
    run_check(f"SEC-{_i + 1:02d}", "Key Vault", f"Read secret '{_key}'", make_secret_read(_key),
              requires=("SEC-01",))

# COMMAND ----------

# --- CHECKS --- Kafka -> Landing -> Bronze --------------------------------

KS = CFG.get("kafka", {})


def kafka_options(topic):
    scope = CFG["secrets"]["scope"]
    opts = {
        "kafka.bootstrap.servers": KS["bootstrap_servers"],
        "subscribe": topic,
        "failOnDataLoss": "false",
    }
    mode = KS.get("auth_mode", "sasl_plain")
    if mode == "sasl_plain":
        user = get_secret(scope, KS["api_key_secret"])
        pwd = get_secret(scope, KS["api_secret_secret"])
        jaas = (f'{KS["jaas_class"]} required username="{user}" password="{pwd}";')
        opts.update({
            "kafka.security.protocol": "SASL_SSL",
            "kafka.sasl.mechanism": "PLAIN",
            "kafka.sasl.jaas.config": jaas,
        })
    elif mode == "ssl_cert":
        ssl = KS["ssl"]
        opts.update({
            "kafka.security.protocol": "SSL",
            "kafka.ssl.truststore.location": ssl["truststore_location"],
            "kafka.ssl.truststore.password": get_secret(scope, ssl["truststore_password_secret"]),
            "kafka.ssl.keystore.location": ssl["keystore_location"],
            "kafka.ssl.keystore.password": get_secret(scope, ssl["keystore_password_secret"]),
            "kafka.ssl.key.password": get_secret(scope, ssl["key_password_secret"]),
        })
    else:
        raise ValueError(f"unknown kafka.auth_mode '{mode}'")
    return opts


def kafka_sample_df():
    reader = spark.read.format("kafka").options(**kafka_options(KS["test_topic"]))
    lookback = KS.get("lookback_hours")
    if lookback:
        start_ms = int((time.time() - float(lookback) * 3600) * 1000)
        reader = reader.option("startingTimestamp", str(start_ms))
    else:
        reader = reader.option("startingOffsets", "earliest")
    reader = reader.option("endingOffsets", "latest")
    return reader.load().limit(int(KS.get("sample_messages", 20)))


def need_kafka():
    if not KS.get("enabled", False):
        raise Skip("kafka.enabled is false in config")
    req = {"kafka.bootstrap_servers": KS.get("bootstrap_servers"), "kafka.test_topic": KS.get("test_topic")}
    if KS.get("auth_mode", "sasl_plain") == "ssl_cert":
        for k, v in (KS.get("ssl") or {}).items():
            req[f"kafka.ssl.{k}"] = v
    else:
        req["kafka.api_key_secret"] = KS.get("api_key_secret")
        req["kafka.api_secret_secret"] = KS.get("api_secret_secret")
    skip_if_unset(**req)


def check_kafka_connect():
    need_kafka()
    n = len(kafka_sample_df().collect())   # payload is not printed or stored
    STATE["kafka_read_n"] = n
    if n == 0:
        raise Warn(f"connected to topic '{KS['test_topic']}' but no messages in the lookback window")
    return f"read {n} message(s) from '{KS['test_topic']}'"


def check_kafka_landing():
    need_kafka()
    if STATE.get("kafka_read_n", 0) == 0:
        raise Skip("no messages to land")
    ts = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    path = f"{LANDING_ROOT}/kafka_{ts}"
    df = kafka_sample_df().select(
        F.col("topic").alias("kafka_topic"),
        F.col("partition").alias("__kafka_partition"), F.col("offset").alias("__kafka_offset"),
        F.col("timestamp").alias("__kafka_timestamp"),
        F.col("key").alias("raw_key"),
        F.col("value").alias("raw_value"),
        F.lit(KS.get("source_system", "TIA")).alias("__source_system"),
        F.current_timestamp().alias("__load_timestamp"),
    )
    df.write.format("avro").mode("overwrite").save(path)
    n = spark.read.format("avro").load(path).count()
    STATE["kafka_landing_path"] = path
    STATE["kafka_landed_n"] = n
    if n == 0:
        raise AssertionError("Avro files written but nothing read back")
    return f"{n} message(s) written to Landing as Avro"


def check_kafka_bronze():
    need_kafka()
    src = STATE.get("kafka_landing_path")
    if not src:
        raise Skip("nothing in Landing to load")
    ensure_schema("bronze")
    tbl = tname("bronze", "kafka")
    CLEANUP_TABLES.append(tbl)
    ck = f"{CHECKPOINT_ROOT}/kafka_bronze"
    stream = (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "avro")
        .option("cloudFiles.schemaLocation", f"{ck}/schema")
        .load(src)
        .writeStream
        .option("checkpointLocation", f"{ck}/cp")
        .trigger(availableNow=True)
        .toTable(tbl)
    )
    stream.awaitTermination()
    n = spark.table(tbl).count()
    if n != STATE["kafka_landed_n"]:
        raise AssertionError(f"Landing had {STATE['kafka_landed_n']} rows, Bronze has {n}")
    dup = scalar(f"SELECT count(*) FROM (SELECT __kafka_partition, __kafka_offset FROM {tbl} "
                 f"GROUP BY ALL HAVING count(*) > 1)")
    if dup:
        raise AssertionError(f"{dup} duplicated (partition, offset) pair(s) in Bronze")
    # second run on the same checkpoint must add nothing (Auto Loader remembers processed files)
    (spark.readStream.format("cloudFiles").option("cloudFiles.format", "avro")
     .option("cloudFiles.schemaLocation", f"{ck}/schema").load(src)
     .writeStream.option("checkpointLocation", f"{ck}/cp").trigger(availableNow=True)
     .toTable(tbl).awaitTermination())
    n2 = spark.table(tbl).count()
    if n2 != n:
        raise AssertionError(f"re-run on the same checkpoint added {n2 - n} row(s)")
    return (f"Auto Loader loaded {n} row(s) into Bronze test table with model metadata columns; "
            "(partition, offset) unique; re-run added 0 rows")


def check_schema_registry():
    need_kafka()
    sr = KS.get("schema_registry", {})
    if not sr.get("enabled", False):
        raise Skip("kafka.schema_registry.enabled is false in config")
    import requests
    cert = (sr["client_cert"], sr["client_key"]) if sr.get("client_cert") else None
    resp = requests.get(
        sr["url"].rstrip("/") + "/subjects",
        timeout=20, cert=cert, verify=sr.get("ca_bundle") or True,
    )
    resp.raise_for_status()
    return f"reachable, {len(resp.json())} subject(s) visible (names not shown)"


run_check("KAF-00", "Kafka", "Schema Registry reachable", check_schema_registry, critical=False)
run_check("KAF-01", "Kafka", "Connect and read sample messages", check_kafka_connect)
run_check("KAF-02", "Kafka", "Write messages to Landing (Avro)", check_kafka_landing, requires=("KAF-01", "STO-01"))
run_check("KAF-03", "Kafka", "Auto Loader: Landing -> Bronze", check_kafka_bronze, requires=("KAF-02", "CAT-W-BR"))

# COMMAND ----------

# --- CHECKS --- JDBC -> timestamped Parquet in Landing (+ match to Bronze model) ----

JS = CFG.get("jdbc", {})


def jdbc_base_reader(conn):
    scope = CFG["secrets"]["scope"]
    return (
        spark.read.format("jdbc")
        .option("url", conn["url"])
        .option("user", get_secret(scope, conn["user_secret"]))
        .option("password", get_secret(scope, conn["password_secret"]))
        .option("driver", conn.get("driver", "oracle.jdbc.OracleDriver"))
    )


def need_jdbc(conn=None):
    if not JS.get("enabled", False):
        raise Skip("jdbc.enabled is false in config")
    if conn:
        skip_if_unset(**{f"jdbc.{conn['name']}.url": conn.get("url"),
                         f"jdbc.{conn['name']}.user_secret": conn.get("user_secret"),
                         f"jdbc.{conn['name']}.password_secret": conn.get("password_secret")})


def model_etl_objects():
    """Bronze ETL tables by source object, e.g. {'MPU2.SCO_BDT_TASK': ('kcl.sco_bdt_task', {...})}."""
    out = {}
    for key, t in (MODEL.get("layers", {}).get("bronze", {}).get("tables", {}) or {}).items():
        if t.get("kind", "").startswith("etl") and t.get("source_object"):
            out[t["source_object"].upper()] = (key, t)
    return out


def tables_for(conn):
    """tables: [..] as listed, or 'auto' = every model ETL object whose owner is in conn.owners."""
    tables = conn.get("tables", [])
    if tables == "auto":
        owners = [o.upper() for o in conn.get("owners", [])]
        return sorted(o for o in model_etl_objects() if o.split(".")[0] in owners)
    return tables


def make_jdbc_ping(conn):
    def _fn():
        need_jdbc(conn)
        query = conn.get("ping_query", "SELECT 1 FROM DUAL")
        jdbc_base_reader(conn).option("query", query).load().first()
        return "connection and simple query OK"
    return _fn


def make_jdbc_table(conn, table):
    def _fn():
        need_jdbc(conn)
        query = f"SELECT * FROM {table} WHERE ROWNUM <= {SAMPLE_ROWS}"   # read-only
        df = jdbc_base_reader(conn).option("query", query).load()
        n = df.count()
        ts = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
        path = f"{LANDING_ROOT}/jdbc/{table.replace('.', '_').lower()}_{ts}"
        df.coalesce(1).write.mode("overwrite").parquet(path)
        back = spark.read.parquet(path).count()
        if back != n:
            raise AssertionError(f"read {n} rows but Parquet has {back}")
        STATE[f"jdbc_cols_{table.upper()}"] = [c.lower() for c in df.columns]
        if n == 0:
            raise Warn(f"{table} readable ({len(df.columns)} columns) but returned 0 rows")
        return f"{n} row(s), {len(df.columns)} column(s) written as timestamped Parquet"
    return _fn


def make_jdbc_model_match(table):
    """Source columns must be exactly the non-metadata columns of the Bronze table in the model."""
    def _fn():
        need_model("bronze")
        got = STATE.get(f"jdbc_cols_{table.upper()}")
        if got is None:
            raise Skip("source columns not read")
        hit = model_etl_objects().get(table.upper())
        if not hit:
            raise Warn(f"{table} is not a source object of any Bronze table in the model")
        key, t = hit
        want = [c["name"].lower() for c in t["columns"] if not c["name"].startswith("__")]
        missing, extra = sorted(set(want) - set(got)), sorted(set(got) - set(want))
        if missing or extra:
            raise Warn(f"-> {key}: in model but not in source {missing[:6]}; in source but not in model {extra[:6]}")
        return f"-> {key}: all {len(want)} source columns match the Bronze model"
    return _fn


for _c in JS.get("connections", []):
    _cid = _c["name"]
    run_check(f"JDBC-P-{_cid}", "JDBC", f"Connect to {_cid}", make_jdbc_ping(_c))
    for _t in tables_for(_c):
        run_check(f"JDBC-T-{_t}", "JDBC", f"Read {_t} -> Landing Parquet", make_jdbc_table(_c, _t),
                  requires=(f"JDBC-P-{_cid}", "STO-01"))
        run_check(f"JDBC-M-{_t}", "JDBC", f"{_t} columns match Bronze model", make_jdbc_model_match(_t),
                  critical=False, requires=(f"JDBC-T-{_t}", "MOD-00"))
if not JS.get("connections"):
    run_check("JDBC-00", "JDBC", "At least one JDBC connection configured",
              lambda: (_ for _ in ()).throw(Skip("no JDBC connections in config")))

# COMMAND ----------

# --- CHECKS --- Landing files (KCC codelists, manual mapping) -> Bronze -----

FS = CFG.get("files", {})


def model_file_tables():
    return {k: t for k, t in (MODEL.get("layers", {}).get("bronze", {}).get("tables", {}) or {}).items()
            if t.get("kind") == "landing_file" and t.get("file_pattern")}


def latest_file(folder, pattern):
    import fnmatch
    hits = [f for f in dbutils.fs.ls(folder) if fnmatch.fnmatch(f.name, pattern)]
    if not hits:
        return None
    return sorted(hits, key=lambda f: getattr(f, "modificationTime", 0))[-1]


def _norm_col(c):
    return re.sub(r"[^a-z0-9]", "", str(c).lower())


def csv_reader():
    return (spark.read.option("header", "true").option("sep", FS.get("delimiter", ";"))
            .option("encoding", FS.get("encoding", "UTF-8")))


def make_file_check(key, t):
    def _fn():
        if not FS.get("enabled", False):
            raise Skip("files.enabled is false in config")
        folder = (FS.get("folders") or {}).get(t["schema"])
        skip_if_unset(**{f"files.folders.{t['schema']}": folder})
        f = latest_file(folder, t["file_pattern"])
        if f is None:
            raise AssertionError(f"no file matching {t['file_pattern']} in {folder}")
        df = csv_reader().csv(f.path)
        n = df.count()
        got = {_norm_col(c) for c in df.columns}
        want = {_norm_col(c["name"]) for c in t["columns"] if not c["name"].startswith("__")}
        missing = sorted(w for w in want if w not in got)
        STATE[f"file_{key}"] = f.path
        if missing:
            raise Warn(f"{f.name}: {n} row(s); model columns not found in header (name-normalised): {missing[:6]}")
        if n == 0:
            raise Warn(f"{f.name} has a header but no rows")
        return f"{f.name}: {n} row(s), header matches the {len(want)} source columns of {key}"
    return _fn


def make_file_autoloader():
    def _fn():
        found = sorted(k for k in STATE if k.startswith("file_"))
        if not found:
            raise Skip("no landing file found by the FILE-* checks")
        path = STATE[found[0]]
        ensure_schema("bronze")
        tbl = tname("bronze", "file")
        CLEANUP_TABLES.append(tbl)
        ck = f"{CHECKPOINT_ROOT}/file_bronze"
        folder = path.rsplit("/", 1)[0]
        name = path.rsplit("/", 1)[1]
        (spark.readStream.format("cloudFiles").option("cloudFiles.format", "csv")
         .option("header", "true").option("sep", FS.get("delimiter", ";"))
         .option("cloudFiles.schemaLocation", f"{ck}/schema")
         .option("rescuedDataColumn", "__rescued_data")
         .option("pathGlobFilter", name).load(folder)
         .select("*", F.col("_metadata.file_name").alias("__file_name"),
                 F.col("_metadata.file_path").alias("__file_path"),
                 F.current_timestamp().alias("__load_timestamp"))
         .writeStream.option("checkpointLocation", f"{ck}/cp").trigger(availableNow=True)
         .toTable(tbl).awaitTermination())
        n = spark.table(tbl).count()
        src = csv_reader().csv(path).count()
        rescued = spark.table(tbl).filter("__rescued_data IS NOT NULL").count()
        if n != src:
            raise AssertionError(f"file has {src} rows, Bronze test table {n}")
        if rescued:
            raise Warn(f"{n} row(s) loaded, {rescued} with __rescued_data")
        return f"Auto Loader CSV -> Bronze test table: {n} row(s), __file_name/__file_path filled, nothing rescued"
    return _fn


_ft = model_file_tables() if MODEL else {}
for _k, _t in sorted(_ft.items()):
    run_check(f"FILE-{_k}", "Files", f"Landing file for {_k} ({_t['file_pattern']})", make_file_check(_k, _t),
              critical=False, requires=("STO-01",))
if _ft:
    run_check("FILE-AL", "Files", "Auto Loader CSV -> Bronze test table (first file found)", make_file_autoloader(),
              critical=False, requires=("STO-01", "CAT-W-BR"))

# COMMAND ----------

# --- CHECKS --- Bronze -> Silver -> Gold with the model's own load pattern ----
#
# Dummy data, real conventions (Silver Load_Pattern / 18_Silver_klice_hashe_datumy):
#   Bronze  append-only, Kafka metadata columns, one row per message (duplicates allowed)
#   Silver  <entity>_hkey = md5(natural key), hash_zaznamu = md5(business columns, no technical columns),
#           verze_id, platnost_od_ts / platnost_do_ts with TIMESTAMP'9999-12-31' for the open version,
#           smazano_priznak (soft delete), __zdrojovy_system, __nacteno_ts, _hist + current table
#   Gold    fact_ table (only GOLD uses dim_/fact_)
# Two loads + a re-run prove: dedup of redelivered messages, new version only on a real change,
# previous version closed, soft delete, current = open versions, idempotent re-run.

def scd2_violations(hist, cur, hkey, has_hash=True, has_verze=True, open_must_exist=False):
    """Checks the load must enforce because Delta cannot (Silver Load_Pattern, block 2). Returns {check: count}."""
    v = {}
    v["current key not unique"] = scalar(f"SELECT count(*) - count(DISTINCT {hkey}) FROM {cur}") if cur else 0
    v["history (key, platnost_od_ts) not unique"] = scalar(
        f"SELECT count(*) FROM (SELECT {hkey}, platnost_od_ts FROM {hist} GROUP BY ALL HAVING count(*) > 1)")
    v["more than one open version"] = scalar(
        f"SELECT count(*) FROM (SELECT {hkey} FROM {hist} WHERE platnost_do_ts = {HIGH_DATE} "
        f"GROUP BY ALL HAVING count(*) > 1)")
    if open_must_exist:
        v["key without open version"] = scalar(
            f"SELECT count(*) FROM (SELECT {hkey} FROM {hist} GROUP BY ALL "
            f"HAVING sum(CASE WHEN platnost_do_ts = {HIGH_DATE} THEN 1 ELSE 0 END) = 0)")
    v["open version with NULL or reversed interval"] = scalar(
        f"SELECT count(*) FROM {hist} WHERE platnost_do_ts IS NULL OR platnost_od_ts > platnost_do_ts")
    v["overlapping intervals"] = scalar(
        f"SELECT count(*) FROM (SELECT platnost_od_ts, lag(platnost_do_ts) OVER "
        f"(PARTITION BY {hkey} ORDER BY platnost_od_ts) AS prev_do FROM {hist}) WHERE prev_do >= platnost_od_ts")
    if cur:
        cond = "OR o.hash_zaznamu <> c.hash_zaznamu" if has_hash else ""
        v["current does not match open history"] = scalar(
            f"SELECT count(*) FROM (SELECT * FROM {hist} WHERE platnost_do_ts = {HIGH_DATE}) o "
            f"FULL OUTER JOIN {cur} c ON o.{hkey} = c.{hkey} "
            f"WHERE o.{hkey} IS NULL OR c.{hkey} IS NULL {cond}")
    if has_verze:
        v["verze_id not unique"] = scalar(f"SELECT count(*) - count(DISTINCT verze_id) FROM {hist}")
    return {k: n for k, n in v.items() if n}


def check_medallion():
    for layer in ("bronze", "silver", "gold"):
        ensure_schema(layer)
    b, d = tname("bronze", "flow_msg"), tname("bronze", "flow_del")
    h, c, stg = tname("silver", "flow_hist"), tname("silver", "flow"), tname("silver", "flow_stg")
    g = tname("gold", "fact_flow")
    CLEANUP_TABLES.extend([b, d, h, c, stg, g])

    spark.sql(f"""CREATE TABLE {b} (application_id INT, policy_number BIGINT, yearly_premium DECIMAL(38,2),
        status INT, data_updated_at TIMESTAMP, __kafka_partition INT, __kafka_offset BIGINT,
        __source_system STRING, __load_timestamp TIMESTAMP)""")
    spark.sql(f"""CREATE TABLE {d} (application_id INT, policy_number BIGINT, deleted_at TIMESTAMP,
        __kafka_partition INT, __kafka_offset BIGINT, __source_system STRING, __load_timestamp TIMESTAMP)""")
    spark.sql(f"""CREATE TABLE {h} (flow_hkey STRING NOT NULL, application_id INT, policy_number BIGINT,
        yearly_premium DECIMAL(38,2), status INT, smazano_priznak BOOLEAN NOT NULL, hash_zaznamu STRING NOT NULL,
        verze_id STRING NOT NULL, platnost_od_ts TIMESTAMP NOT NULL, platnost_do_ts TIMESTAMP NOT NULL,
        __zdrojovy_system STRING NOT NULL, __nacteno_ts TIMESTAMP NOT NULL)""")
    spark.sql(f"""CREATE TABLE {c} (flow_hkey STRING NOT NULL, application_id INT, policy_number BIGINT,
        yearly_premium DECIMAL(38,2), status INT, smazano_priznak BOOLEAN NOT NULL, hash_zaznamu STRING NOT NULL,
        platnost_od_ts TIMESTAMP NOT NULL, __zdrojovy_system STRING NOT NULL, __nacteno_ts TIMESTAMP NOT NULL)""")

    def load_silver(watermark):
        """Load_Pattern steps 1, 8, 9, 12-15, 17, 18 on the dummy data."""
        spark.sql(f"DROP TABLE IF EXISTS {stg}")
        spark.sql(f"""CREATE TABLE {stg} AS
            WITH src AS (
              SELECT application_id, policy_number, yearly_premium, status, false AS smazano_priznak,
                     data_updated_at AS change_ts, __source_system
              FROM {b} WHERE __load_timestamp > TIMESTAMP'{watermark}'
              UNION ALL
              SELECT x.application_id, x.policy_number, o.yearly_premium, o.status, true,
                     x.deleted_at, x.__source_system
              FROM {d} x JOIN {c} o ON o.application_id = x.application_id AND o.policy_number = x.policy_number
              WHERE x.__load_timestamp > TIMESTAMP'{watermark}'
            ),
            latest AS (
              SELECT *, row_number() OVER (PARTITION BY application_id, policy_number ORDER BY change_ts DESC) rn
              FROM src
            ),
            keyed AS (
              SELECT md5(concat_ws('||', cast(policy_number AS STRING), cast(application_id AS STRING))) AS flow_hkey,
                     application_id, policy_number, yearly_premium, status, smazano_priznak,
                     md5(concat_ws('||', cast(yearly_premium AS STRING), cast(status AS STRING),
                                   cast(smazano_priznak AS STRING))) AS hash_zaznamu,
                     change_ts, __source_system
              FROM latest WHERE rn = 1
            )
            SELECT k.* FROM keyed k
            LEFT JOIN (SELECT * FROM {h} WHERE platnost_do_ts = {HIGH_DATE}) o ON o.flow_hkey = k.flow_hkey
            WHERE o.flow_hkey IS NULL OR o.hash_zaznamu <> k.hash_zaznamu""")
        spark.sql(f"""MERGE INTO {h} t USING {stg} s
            ON t.flow_hkey = s.flow_hkey AND t.platnost_do_ts = {HIGH_DATE}
            WHEN MATCHED THEN UPDATE SET t.platnost_do_ts = s.change_ts - INTERVAL 1 MICROSECOND""")
        spark.sql(f"""INSERT INTO {h}
            SELECT flow_hkey, application_id, policy_number, yearly_premium, status, smazano_priznak, hash_zaznamu,
                   md5(concat_ws('||', flow_hkey, hash_zaznamu)), change_ts, {HIGH_DATE},
                   __source_system, current_timestamp()
            FROM {stg}""")
        spark.sql(f"""MERGE INTO {c} t
            USING (SELECT * FROM {h} WHERE platnost_do_ts = {HIGH_DATE}) s ON t.flow_hkey = s.flow_hkey
            WHEN MATCHED AND t.hash_zaznamu <> s.hash_zaznamu THEN UPDATE SET
              t.yearly_premium = s.yearly_premium, t.status = s.status, t.smazano_priznak = s.smazano_priznak,
              t.hash_zaznamu = s.hash_zaznamu, t.platnost_od_ts = s.platnost_od_ts,
              t.__zdrojovy_system = s.__zdrojovy_system, t.__nacteno_ts = s.__nacteno_ts
            WHEN NOT MATCHED THEN INSERT (flow_hkey, application_id, policy_number, yearly_premium, status,
              smazano_priznak, hash_zaznamu, platnost_od_ts, __zdrojovy_system, __nacteno_ts)
              VALUES (s.flow_hkey, s.application_id, s.policy_number, s.yearly_premium, s.status,
              s.smazano_priznak, s.hash_zaznamu, s.platnost_od_ts, s.__zdrojovy_system, s.__nacteno_ts)""")

    def expect(sql, want, what):
        got = scalar(sql)
        if got != want:
            raise AssertionError(f"{what}: expected {want}, got {got}")

    # load 1: four messages, one is a redelivery of the same state
    spark.sql(f"""INSERT INTO {b} VALUES
      (1, 1001, 1000.00, 1, TIMESTAMP'2026-01-01 10:00:00', 0, 1, 'TIA', TIMESTAMP'2026-01-01 10:05:00'),
      (1, 1001, 1000.00, 1, TIMESTAMP'2026-01-01 10:00:00', 0, 2, 'TIA', TIMESTAMP'2026-01-01 10:05:00'),
      (1, 1002,  500.00, 1, TIMESTAMP'2026-01-01 10:00:00', 1, 1, 'TIA', TIMESTAMP'2026-01-01 10:05:00'),
      (1, 1003,  700.00, 1, TIMESTAMP'2026-01-01 10:00:00', 1, 2, 'TIA', TIMESTAMP'2026-01-01 10:05:00')""")
    load_silver("1900-01-01 00:00:00")
    expect(f"SELECT count(*) FROM {h}", 3, "history rows after load 1 (redelivery deduplicated)")
    expect(f"SELECT count(*) FROM {c}", 3, "current rows after load 1")

    # load 2: 1001 premium changes, 1002 resent unchanged, 1003 deleted
    spark.sql(f"""INSERT INTO {b} VALUES
      (1, 1001, 1200.00, 1, TIMESTAMP'2026-02-01 10:00:00', 0, 3, 'TIA', TIMESTAMP'2026-02-01 10:05:00'),
      (1, 1002,  500.00, 1, TIMESTAMP'2026-02-01 09:00:00', 1, 3, 'TIA', TIMESTAMP'2026-02-01 10:05:00')""")
    spark.sql(f"""INSERT INTO {d} VALUES
      (1, 1003, TIMESTAMP'2026-02-01 11:00:00', 2, 1, 'TIA', TIMESTAMP'2026-02-01 10:05:00')""")
    load_silver("2026-01-01 10:05:00")
    expect(f"SELECT count(*) FROM {h}", 5, "history rows after load 2 (change + soft delete, unchanged skipped)")
    expect(f"SELECT count(*) FROM {h} WHERE policy_number = 1002", 1, "versions of the unchanged record")
    expect(f"SELECT CAST(yearly_premium AS STRING) FROM {c} WHERE policy_number = 1001", "1200.00",
           "current premium of the changed record")
    expect(f"SELECT CAST(max(platnost_do_ts) AS STRING) FROM {h} WHERE policy_number = 1001 "
           f"AND platnost_do_ts < {HIGH_DATE}", "2026-02-01 09:59:59.999999", "closed version end")
    expect(f"SELECT count(*) FROM {c} WHERE policy_number = 1003 AND smazano_priznak", 1,
           "soft-deleted record kept and flagged")

    # re-run of load 2: idempotent
    load_silver("2026-01-01 10:05:00")
    expect(f"SELECT count(*) FROM {h}", 5, "history rows after re-running load 2")
    bad = scd2_violations(h, c, "flow_hkey", open_must_exist=True)
    if bad:
        raise AssertionError(f"SCD2 rule violations: {bad}")

    spark.sql(f"""CREATE TABLE {g} AS
        SELECT status, count(*) AS contract_count, sum(yearly_premium) AS yearly_premium_total
        FROM {c} WHERE NOT smazano_priznak GROUP BY status""")
    expect(f"SELECT CAST(sum(yearly_premium_total) AS STRING) FROM {g}", "1700.00", "Gold total premium")
    expect(f"SELECT sum(contract_count) FROM {g}", 2, "Gold contract count")
    return ("Bronze (append-only, redelivery) -> Silver (_hkey/hash_zaznamu/verze_id, SCD2 with 9999-12-31, "
            "soft delete, current = open versions, idempotent re-run) -> Gold fact_ aggregate OK")


run_check("FLOW-01", "Medallion", "Model load pattern on dummy data Bronze -> Silver -> Gold", check_medallion,
          requires=("CAT-W-BR", "CAT-W-SI", "CAT-W-GO"))

# COMMAND ----------

# --- CHECKS --- data quality on the real Bronze / Silver tables (when they hold data) ----

DQ = CFG.get("dq", {})


def _fq(layer, key):
    s, t = key.split(".")
    return f"{q(CATS[layer])}.{q(s)}.{q(t)}"


def _nonempty(layer, key):
    present = STATE.get(f"present_tables_{layer}") or {}
    if key not in present:
        return False
    return spark.sql(f"SELECT 1 FROM {_fq(layer, key)} LIMIT 1").count() > 0


def check_bronze_dq():
    if not DQ.get("enabled", True):
        raise Skip("dq.enabled is false in config")
    need_model("bronze")
    tables = MODEL["layers"]["bronze"]["tables"]
    done, problems, notes = 0, [], []
    for key, t in sorted(tables.items()):
        if not _nonempty("bronze", key):
            continue
        done += 1
        fq = _fq("bronze", key)
        nul = scalar(f"SELECT count(*) FROM {fq} WHERE __load_timestamp IS NULL OR __source_system IS NULL")
        if nul:
            problems.append(f"{key}: {nul} row(s) without __load_timestamp/__source_system")
        if t["kind"] in ("kafka_sync", "kafka_quarantine"):
            dup = scalar(f"SELECT count(*) FROM (SELECT __kafka_partition, __kafka_offset FROM {fq} "
                         f"GROUP BY ALL HAVING count(*) > 1)")
            if dup:
                problems.append(f"{key}: {dup} duplicated (partition, offset)")
        if t["kind"] == "kafka_sync":
            bad = scalar(f"SELECT count(*) FROM {fq} WHERE NOT __message_valid_flag")
            if bad:
                notes.append(f"{key}: {bad} message(s) with __message_valid_flag = FALSE")
        if t["kind"] == "kafka_quarantine":
            open_q = scalar(f"SELECT count(*) FROM {fq} WHERE NOT coalesce(resolved_flag, false)")
            if open_q:
                notes.append(f"{key}: {open_q} unresolved quarantined message(s)")
        if t["kind"] == "landing_file":
            nf = scalar(f"SELECT count(*) FROM {fq} WHERE __file_name IS NULL")
            if nf:
                problems.append(f"{key}: {nf} row(s) without __file_name")
        if t["kind"] == "etl_full" and t["primary_key"]:
            pk = ", ".join(t["primary_key"])
            dup = scalar(f"SELECT count(*) FROM (SELECT {pk} FROM {fq} WHERE __load_timestamp = "
                         f"(SELECT max(__load_timestamp) FROM {fq}) GROUP BY ALL HAVING count(*) > 1)")
            if dup:
                problems.append(f"{key}: {dup} duplicated key(s) in the latest snapshot")
    if done == 0:
        raise Skip("no model Bronze table holds data yet")
    if problems:
        raise AssertionError(f"{len(problems)} problem(s) in {done} table(s): " + " | ".join(problems[:6]))
    if notes:
        raise Warn(f"{done} table(s) OK; to review: " + " | ".join(notes[:6]))
    return f"{done} Bronze table(s): metadata filled, (partition, offset) unique, latest snapshot keys unique"


def check_silver_dq():
    if not DQ.get("enabled", True):
        raise Skip("dq.enabled is false in config")
    need_model("silver")
    tables = MODEL["layers"]["silver"]["tables"]
    done, problems = 0, []
    for key, t in sorted(tables.items()):
        if t["kind"] != "history" or not _nonempty("silver", key):
            continue
        cur_key = key[:-5]
        cur = _fq("silver", cur_key) if cur_key in (STATE.get("present_tables_silver") or {}) else None
        names = {x["name"] for x in t["columns"]}
        bad = scd2_violations(_fq("silver", key), cur, t["hkey"], has_hash="hash_zaznamu" in names,
                              has_verze="verze_id" in names,
                              open_must_exist=t.get("materialization") == "incremental")
        done += 1
        if bad:
            problems.append(f"{t['entity']}: {bad}")
    if done == 0:
        raise Skip("no Silver history table holds data yet")
    if problems:
        raise AssertionError(f"{len(problems)}/{done} entity(ies) break SCD2 rules: " + " | ".join(problems[:4]))
    return f"{done} Silver entity(ies): keys unique, max one open version, no overlaps, current = open history"


run_check("DQ-BR", "Data quality", "Real Bronze tables: metadata and uniqueness rules", check_bronze_dq,
          critical=False, requires=("MOD-TBL-BR",))
run_check("DQ-SI", "Data quality", "Real Silver tables: SCD2 and key rules", check_silver_dq,
          critical=False, requires=("MOD-TBL-SI",))

# COMMAND ----------

# --- CHECKS --- optional: run the real framework for one topic -------------

FW = CFG.get("framework", {})


def make_framework_run(job_type):
    def _fn():
        if not FW.get("enabled", False):
            raise Skip("framework.enabled is false in config")
        out = dbutils.notebook.run(
            FW["notebook_path"],
            int(FW.get("timeout_seconds", 1800)),
            {
                "metadata_file": FW["metadata_file"],
                "environment": FW.get("environment", ENV_LABEL),
                "job_type": job_type,
            },
        )
        return f"framework '{job_type}' run finished ({str(out)[:100]})"
    return _fn


run_check("FW-01", "Framework", "Framework landing run (one topic)", make_framework_run("landing"), critical=False)
run_check("FW-02", "Framework", "Framework autoloader run (one topic)", make_framework_run("autoloader"),
          critical=False, requires=("FW-01",))

# COMMAND ----------

# --- CLEANUP, RESULTS, REPORT, VERDICT -------------------------------------

def cleanup():
    if not CLEANUP:
        print("cleanup disabled - test objects were left in place")
        return
    for tbl in CLEANUP_TABLES:
        try:
            spark.sql(f"DROP TABLE IF EXISTS {tbl}")
        except Exception as e:
            print(f"could not drop {tbl}: {redact(e)[:120]}")
    for s in CREATED_SCHEMAS:
        try:
            spark.sql(f"DROP SCHEMA IF EXISTS {s}")
        except Exception as e:
            print(f"could not drop schema {s}: {redact(e)[:120]}")
    for p in CLEANUP_PATHS:
        try:
            dbutils.fs.rm(p, True)
        except Exception as e:
            print(f"could not remove {p}: {redact(e)[:120]}")


def persist_results():
    meta_cat = CATS["meta"]
    ensure_schema("meta")
    tbl = f"{q(meta_cat)}.{q(test_schema('meta'))}.{q('smoke_test_results')}"
    spark.sql(f"""
        CREATE TABLE IF NOT EXISTS {tbl} (
          run_id STRING, environment STRING, check_id STRING, area STRING,
          name STRING, status STRING, critical BOOLEAN, detail STRING,
          duration_secs DOUBLE, executed_at TIMESTAMP, executed_by STRING)
    """)
    user = spark.sql("SELECT current_user()").first()[0]
    schema = StructType([
        StructField("run_id", StringType()), StructField("environment", StringType()),
        StructField("check_id", StringType()), StructField("area", StringType()),
        StructField("name", StringType()), StructField("status", StringType()),
        StructField("critical", BooleanType()), StructField("detail", StringType()),
        StructField("duration_secs", DoubleType()), StructField("executed_at", TimestampType()),
        StructField("executed_by", StringType()),
    ])
    rows = [(RUN_ID, ENV_LABEL, r["check_id"], r["area"], r["name"], r["status"],
             r["critical"], r["detail"], float(r["duration_secs"]), r["executed_at"], user)
            for r in RESULTS]
    spark.createDataFrame(rows, schema).write.mode("append").saveAsTable(tbl)
    return tbl


def write_report(md):
    report_dir = CFG["paths"].get("report_dir", "")
    if not report_dir or "<" in report_dir:
        return None
    name = f"smoke_test_{ENV_LABEL}_{STARTED:%Y%m%d_%H%M%S}_{RUN_ID}.md"
    path = f"{report_dir.rstrip('/')}/{name}"
    dbutils.fs.put(path, md, True)
    return path


cleanup()

try:
    print("results saved to:", persist_results())
except Exception as e:
    print("WARNING - could not save results table:", redact(e)[:200])

REPORT_MD = build_report_md()
try:
    saved = write_report(REPORT_MD)
    print("report file:", saved or "not written (report_dir not configured)")
except Exception as e:
    print("WARNING - could not write report file:", redact(e)[:200])

print()
print(REPORT_MD)

# COMMAND ----------

FINAL = verdict()
print(f"\nVERDICT: {FINAL}")
if FINAL == "NOT READY":
    failed = [r["check_id"] for r in RESULTS if r["critical"] and r["status"] == "FAIL"]
    raise RuntimeError(f"Smoke test failed. Critical checks failed: {failed}")

dbutils.notebook.exit(json.dumps({"run_id": RUN_ID, "verdict": FINAL}))

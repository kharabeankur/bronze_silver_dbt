"""
generate_expected_model.py
--------------------------
Builds smoke_test_model.json from the data-model deliverables, so the smoke test checks the
environment against the model instead of against hand-typed lists.

Inputs (same folder or pass paths):
  06_Bronze_DDL_databricks.sql
  15_Silver_DDL_databricks.sql
  11_Bronze_physical_model_databricks.xlsx   (optional: source object / ingestion per table)
  14_Silver_physical_model_databricks.xlsx   (optional: dbt materialisation per entity)

The output is catalog-agnostic: the DDL catalog names (dbx_cz_gcz_dev_czlake_*) are recorded but the
smoke test uses the catalogs from smoke_test_config.yml. Re-run this script whenever the DDL changes.

    python generate_expected_model.py --bronze 06_...sql --silver 15_...sql \
        --bronze-xlsx 11_...xlsx --silver-xlsx 14_...xlsx --out smoke_test_model.json
"""
import argparse
import json
import re
from datetime import datetime, timezone

COL_RE = re.compile(
    r"^(?P<name>`?[A-Za-z_][\w]*`?)\s+(?P<type>.+?)"
    r"(?P<nn>\s+NOT NULL)?(?:\s+COMMENT\s+'(?:[^'\\]|\\.|'')*')?\s*,?\s*$"
)
TABLE_RE = re.compile(
    r"CREATE TABLE IF NOT EXISTS (?P<fq>[\w]+\.[\w]+\.[\w]+) \((?P<body>.*?)\n\)\s*\nUSING DELTA(?P<tail>.*?);\s*\n",
    re.S,
)


def _split_top_level(body):
    """Split the column list on commas that are not inside <...> or (...) or quotes."""
    parts, buf, depth, quote = [], [], 0, False
    i = 0
    while i < len(body):
        ch = body[i]
        if ch == "'" and not quote:
            quote = True
        elif ch == "'" and quote:
            if i + 1 < len(body) and body[i + 1] == "'":
                buf.append(ch); i += 1
            elif i > 0 and body[i - 1] == "\\":
                pass
            else:
                quote = False
        elif not quote and ch in "<(":
            depth += 1
        elif not quote and ch in ">)":
            depth -= 1
        if ch == "," and depth == 0 and not quote:
            parts.append("".join(buf)); buf = []
        else:
            buf.append(ch)
        i += 1
    if "".join(buf).strip():
        parts.append("".join(buf))
    return [p.strip() for p in parts if p.strip()]


def norm_type(t):
    t = re.sub(r"GENERATED\s+ALWAYS\s+AS\s+IDENTITY(\s*\([^)]*\))?", "", t, flags=re.I)
    t = t.replace("`", "")
    return re.sub(r"\s+", "", t).lower()


def parse_ddl(path, layer):
    s = open(path, encoding="utf-8").read()
    schemas, tables, catalog = {}, {}, None
    for m in re.finditer(r"CREATE SCHEMA IF NOT EXISTS (\w+)\.(\w+)(?: COMMENT '((?:[^']|'')*)')?;", s):
        catalog = m.group(1)
        schemas.setdefault(m.group(2), {"comment": m.group(3), "tags": {}})
    for m in re.finditer(r"ALTER SCHEMA (\w+)\.(\w+) SET TAGS \((.*?)\);", s):
        schemas.setdefault(m.group(2), {"comment": None, "tags": {}})["tags"].update(
            dict(re.findall(r"'([\w]+)'\s*=\s*'((?:[^'\\]|\\.)*)'", m.group(3))))
    for m in TABLE_RE.finditer(s):
        _, sch, tbl = m.group("fq").split(".")
        cols, pk = [], []
        for part in _split_top_level(m.group("body")):
            if part.upper().startswith("CONSTRAINT"):
                pm = re.search(r"PRIMARY KEY \((.*?)\)", part)
                if pm:
                    pk = [c.strip().strip("`") for c in pm.group(1).split(",")]
                continue
            cm = COL_RE.match(re.sub(r"\s+", " ", part))
            if not cm:
                raise ValueError(f"cannot parse column in {sch}.{tbl}: {part[:120]}")
            cols.append({
                "name": cm.group("name").strip("`"),
                "type": norm_type(cm.group("type")),
                "not_null": bool(cm.group("nn")),
                "identity": "GENERATED ALWAYS AS IDENTITY" in cm.group("type").upper(),
            })
        tail = m.group("tail")
        cl = re.search(r"CLUSTER BY \((.*?)\)", tail)
        props = dict(re.findall(r"'([\w\.]+)'\s*=\s*'((?:[^'\\]|\\.)*)'", tail))
        tables[f"{sch}.{tbl}"] = {
            "schema": sch, "table": tbl, "columns": cols, "primary_key": pk,
            "cluster_by": [c.strip() for c in cl.group(1).split(",")] if cl else [],
            "properties": props, "has_comment": bool(re.search(r"\nCOMMENT '", tail)),
            "has_location": "LOCATION" in tail.upper(),
            "foreign_keys": [],
        }
    for m in re.finditer(
            r"ALTER TABLE \w+\.(\w+\.\w+) ADD CONSTRAINT (\w+) FOREIGN KEY \((.*?)\) "
            r"REFERENCES \w+\.(\w+\.\w+) \((.*?)\)", s):
        child, name, ccols, parent, pcols = m.groups()
        if child in tables:
            tables[child]["foreign_keys"].append({
                "name": name, "columns": [c.strip() for c in ccols.split(",")],
                "parent": parent, "parent_columns": [c.strip() for c in pcols.split(",")]})
    return catalog, schemas, tables


def classify_bronze(t):
    lp = t["properties"].get("load.pattern", "")
    names = {c["name"] for c in t["columns"]}
    if "dead letter" in lp.lower():
        return "kafka_quarantine"
    if "__kafka_offset" in names:
        return "kafka_sync"
    if "landing csv" in lp.lower() or "__file_name" in names:
        return "landing_file"
    if "incremental" in lp.lower():
        return "etl_incremental"
    return "etl_full"


def read_sheet(path, sheet, header_key):
    from openpyxl import load_workbook
    wb = load_workbook(path, read_only=True, data_only=True)
    rows = list(wb[sheet].iter_rows(values_only=True))
    for i, r in enumerate(rows):
        if r and header_key in [str(x) for x in r if x is not None]:
            hdr = [str(x) if x is not None else "" for x in r]
            return [dict(zip(hdr, rr)) for rr in rows[i + 1:] if rr and any(rr)]
    return []


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bronze", default="06_Bronze_DDL_databricks.sql")
    ap.add_argument("--silver", default="15_Silver_DDL_databricks.sql")
    ap.add_argument("--bronze-xlsx", default="11_Bronze_physical_model_databricks.xlsx")
    ap.add_argument("--silver-xlsx", default="14_Silver_physical_model_databricks.xlsx")
    ap.add_argument("--out", default="smoke_test_model.json")
    a = ap.parse_args()

    out = {"generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
           "sources": [a.bronze, a.silver], "ddl_catalogs": {}, "layers": {}}

    bcat, bsch, btab = parse_ddl(a.bronze, "bronze")
    try:
        meta = {(r["Owner"], r["Name"]): r for r in read_sheet(a.bronze_xlsx, "PD_Tables", "Source_Object")}
    except Exception as e:  # noqa: BLE001
        print("bronze xlsx not used:", e); meta = {}
    for k, t in btab.items():
        t["kind"] = classify_bronze(t)
        t["source_system"] = t["properties"].get("source.system")
        m = meta.get((t["schema"], t["table"]), {})
        t["source_object"] = m.get("Source_Object") or t["properties"].get("source.object")
        lp = t["properties"].get("load.pattern", "")
        fm = re.search(r":\s*([\w\.]+\.csv)", lp)
        t["file_pattern"] = fm.group(1).replace("YYYYMMDD", "*") if fm else None
    out["ddl_catalogs"]["bronze"] = bcat
    out["layers"]["bronze"] = {"schemas": bsch, "tables": btab}

    scat, ssch, stab = parse_ddl(a.silver, "silver")
    try:
        dbt = {r["Entita"]: r for r in read_sheet(a.silver_xlsx, "dbt_Config", "Materializace")}
    except Exception as e:  # noqa: BLE001
        print("silver xlsx not used:", e); dbt = {}
    for k, t in stab.items():
        hist = t["table"].endswith("_hist")
        entity = t["table"][:-5] if hist else t["table"]
        t["kind"] = "history" if hist else "current"
        t["entity"] = entity
        t["materialization"] = (dbt.get(entity) or {}).get("Materializace")
        t["hkey"] = f"{entity}_hkey"
    out["ddl_catalogs"]["silver"] = scat
    out["layers"]["silver"] = {"schemas": ssch, "tables": stab}
    out["layers"]["gold"] = {"schemas": {}, "tables": {},
                             "note": "No GOLD DDL delivered (dataflow deck: GOLD not deployed yet)."}

    json.dump(out, open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    for layer, v in out["layers"].items():
        kinds = {}
        for t in v["tables"].values():
            kinds[t["kind"]] = kinds.get(t["kind"], 0) + 1
        print(f"{layer:7} schemas={len(v['schemas']):2} tables={len(v['tables']):3} {kinds}")
    print("written", a.out)


if __name__ == "__main__":
    main()
